import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, n as Card } from "./shell-85x_j55U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-1R-BTFQg.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "درباره",
		back: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pip text-center text-3xl text-heart",
				"aria-hidden": true,
				children: "♥ ♠"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-center text-lg font-semibold",
				children: "ده دویست"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-center text-sm leading-6 text-ink/80",
				children: "برگه امتیاز آفلاین برای بازی دو تیم. حساب دست‌ها، شرط ۸ و حد ۵۰۰ روی همین دستگاه می‌ماند."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-center text-xs text-muted",
			children: "khansalar@gmail.com"
		})]
	});
}
//#endregion
export { AboutPage as component };
