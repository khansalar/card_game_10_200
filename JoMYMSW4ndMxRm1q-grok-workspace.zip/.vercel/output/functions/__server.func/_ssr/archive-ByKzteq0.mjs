import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, i as Num, o as btnClass, p as winnerLabel, r as ConfirmDialog, u as faWhen } from "./shell-85x_j55U.mjs";
import { c as useGameStore, l as deriveGame } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/archive-ByKzteq0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ArchivePage() {
	const games = useGameStore((s) => s.games);
	const hydrated = useGameStore((s) => s.hydrated);
	const removeGame = useGameStore((s) => s.removeGame);
	const [pending, setPending] = (0, import_react.useState)(null);
	const ordered = [...games].sort((a, b) => a.updatedAt < b.updatedAt ? 1 : -1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "تاریخچه بازی‌ها",
		back: true,
		children: [
			!hydrated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "در حال خواندن…"
			}),
			hydrated && ordered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "بازی ذخیره‌شده‌ای نیست."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: ordered.map((game) => {
					const d = deriveGame(game.rounds, game.rules);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl bg-card p-3 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-sm font-semibold",
									children: [
										game.teamA.name,
										" مقابل ",
										game.teamB.name
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-ink/60",
									children: faWhen(game.updatedAt)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-brass",
									children: d.status === "completed" ? "تمام" : "ناتمام"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-lg font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: d.scoreA }),
									" — ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: d.scoreB })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs",
								children: winnerLabel(d.winner, game.teamA.name, game.teamB.name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/play/$gameId",
										params: { gameId: game.id },
										className: btnClass("green", "flex-1"),
										children: d.status === "active" ? "ادامه" : "مشاهده"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/log/$gameId",
										params: { gameId: game.id },
										className: btnClass("line", "flex-1 text-ink"),
										children: "دست‌ها"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: btnClass("danger"),
										onClick: () => setPending(game.id),
										children: "حذف"
									})
								]
							})
						]
					}, game.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: pending !== null,
				title: "حذف بازی؟",
				body: "این بازی فقط از حافظهٔ همین دستگاه پاک می‌شود.",
				confirmLabel: "حذف",
				danger: true,
				onClose: () => setPending(null),
				onConfirm: () => {
					if (pending) removeGame(pending);
					setPending(null);
				}
			})
		]
	});
}
//#endregion
export { ArchivePage as component };
