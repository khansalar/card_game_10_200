import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, i as Num, n as Card, o as btnClass } from "./shell-85x_j55U.mjs";
import { c as useGameStore, l as deriveGame, n as Route, s as useGame } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/detail._gameId._roundId-DTfxP115.js
var import_jsx_runtime = require_jsx_runtime();
function DetailPage() {
	const { gameId, roundId } = Route.useParams();
	const game = useGame(gameId);
	if (!useGameStore((s) => s.hydrated)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "جزئیات دست",
		children: "در حال خواندن…"
	});
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "بازی پیدا نشد",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "این بازی وجود ندارد." })
	});
	const round = deriveGame(game.rounds, game.rules).rounds.find((r) => r.id === roundId);
	if (!round) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "دست پیدا نشد",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "این دست در تاریخچه نیست." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: `دست ${round.number}`,
		eyebrow: "جزئیات",
		back: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamBlock, {
					name: game.teamA.name,
					declared: round.declaredA,
					actual: round.actualA,
					points: round.pointsA,
					success: round.successA,
					earned: round.earnedQualificationA,
					cumulative: round.cumulativeA,
					warning: round.warningA,
					blocked: round.blockedWinA
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-ink/10" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamBlock, {
					name: game.teamB.name,
					declared: round.declaredB,
					actual: round.actualB,
					points: round.pointsB,
					success: round.successB,
					earned: round.earnedQualificationB,
					cumulative: round.cumulativeB,
					warning: round.warningB,
					blocked: round.blockedWinB
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs leading-5 text-muted",
				children: "امتیاز تجمعی بعد از این دست دوباره از اول تاریخچه ساخته می‌شود. ویرایش، دست‌های دیگر را عوض نمی‌کند؛ فقط جمع‌ها را از نو حساب می‌کند."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/round/$gameId",
				params: { gameId },
				search: { edit: roundId },
				className: btnClass("solid", "mt-4 w-full"),
				children: "ویرایش این دست"
			})
		]
	});
}
function TeamBlock({ name, declared, actual, points, success, earned, cumulative, warning, blocked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-sm leading-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"اعلام ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: declared }),
				" · گرفته ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: actual }),
				" ·",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: success ? "text-ok" : "text-heart",
					children: success ? "موفق" : "ناموفق"
				}),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
					value: points,
					signed: true
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-ink/70",
				children: ["جمع بعد از دست: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: cumulative })]
			}),
			earned && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-ok",
				children: "شرط اعلام و گرفتن ۸ در این دست کامل شد."
			}),
			warning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-heart",
				children: "هشدار: این تیم هنوز شرط برد با اعلام و گرفتن ۸ دست را تکمیل نکرده است."
			}),
			blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-heart",
				children: "به ۵۰۰ رسیده اما به‌خاطر شرط ۸ برنده نیست."
			})
		]
	});
}
//#endregion
export { DetailPage as component };
