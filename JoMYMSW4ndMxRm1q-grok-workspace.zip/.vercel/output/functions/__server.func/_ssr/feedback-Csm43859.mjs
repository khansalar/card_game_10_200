//#region node_modules/.nitro/vite/services/ssr/assets/feedback-Csm43859.js
var audio = null;
function context() {
	if (typeof window === "undefined") return null;
	const Ctor = window.AudioContext;
	if (!Ctor) return null;
	if (!audio) audio = new Ctor();
	return audio;
}
function playTone(kind, enabled) {
	if (!enabled) return;
	const ctx = context();
	if (!ctx) return;
	ctx.resume().catch(() => void 0);
	const now = ctx.currentTime;
	(kind === "win" ? [
		523,
		659,
		784
	] : kind === "ok" ? [660] : [220, 180]).forEach((freq, i) => {
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(.05, now + .02 + i * .08);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .18 + i * .08);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(now + i * .08);
		osc.stop(now + .22 + i * .08);
	});
}
function buzz(enabled, pattern = 12) {
	if (!enabled || typeof navigator === "undefined" || !navigator.vibrate) return;
	try {
		navigator.vibrate(pattern);
	} catch {}
}
//#endregion
export { playTone as n, buzz as t };
