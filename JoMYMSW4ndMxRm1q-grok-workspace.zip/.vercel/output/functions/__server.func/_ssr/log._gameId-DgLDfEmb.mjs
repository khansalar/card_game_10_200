import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, i as Num, o as btnClass } from "./shell-85x_j55U.mjs";
import { a as Route$3, c as useGameStore, l as deriveGame, s as useGame } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/log._gameId-DgLDfEmb.js
var import_jsx_runtime = require_jsx_runtime();
function LogPage() {
	const { gameId } = Route$3.useParams();
	const game = useGame(gameId);
	if (!useGameStore((s) => s.hydrated)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "دست‌ها",
		children: "در حال خواندن…"
	});
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "بازی پیدا نشد",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: "این بازی وجود ندارد."
		})
	});
	const derived = deriveGame(game.rounds, game.rules);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "تاریخچه دست‌ها",
		eyebrow: `${game.teamA.name} و ${game.teamB.name}`,
		back: true,
		children: [
			derived.rounds.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "هنوز دستی ثبت نشده است."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-2",
				children: derived.rounds.map((round) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/detail/$gameId/$roundId",
					params: {
						gameId,
						roundId: round.id
					},
					className: "block rounded-2xl bg-card px-3 py-3 text-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center justify-between text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["دست ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.number })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-normal text-ink/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.cumulativeA }),
									" — ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.cumulativeB })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-xs leading-5 text-ink/80",
							children: [
								game.teamA.name,
								": اعلام ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.declaredA }),
								"، گرفته ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.actualA }),
								"،",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
									value: round.pointsA,
									signed: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								game.teamB.name,
								": اعلام ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.declaredB }),
								"، گرفته ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: round.actualB }),
								"،",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
									value: round.pointsB,
									signed: true
								})
							]
						}),
						(round.earnedQualificationA || round.earnedQualificationB) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs text-ok",
							children: "شرط ۸ در این دست کامل شد"
						}),
						(round.warningA || round.warningB) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs text-heart",
							children: "هشدار شرط ۸ برای تیم بالای ۴۰۰"
						})
					]
				}) }, round.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/play/$gameId",
				params: { gameId },
				className: btnClass("line", "mt-4"),
				children: "بازگشت به میز"
			})
		]
	});
}
//#endregion
export { LogPage as component };
