import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, f as ruleLine, n as Card, t as Btn } from "./shell-85x_j55U.mjs";
import { c as useGameStore, l as deriveGame } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-k4nvN7tH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, value, onChange, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-ink/70",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			maxLength: 40,
			placeholder,
			onChange: (e) => onChange(e.target.value),
			className: "min-h-11 w-full rounded-xl border border-line/40 bg-card px-3 text-sm text-ink outline-none focus:border-brass"
		})]
	});
}
function NewGame() {
	const navigate = useNavigate();
	const settings = useGameStore((s) => s.settings);
	const games = useGameStore((s) => s.games);
	const startGame = useGameStore((s) => s.startGame);
	const unfinished = games.filter((g) => deriveGame(g.rounds, g.rules).status === "active").length;
	const [ack, setAck] = (0, import_react.useState)(false);
	const [teamA, setTeamA] = (0, import_react.useState)("تیم الف");
	const [a1, setA1] = (0, import_react.useState)("");
	const [a2, setA2] = (0, import_react.useState)("");
	const [teamB, setTeamB] = (0, import_react.useState)("تیم ب");
	const [b1, setB1] = (0, import_react.useState)("");
	const [b2, setB2] = (0, import_react.useState)("");
	const locked = unfinished > 0 && !ack;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "بازی جدید",
		eyebrow: "ده دویست",
		back: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "تیم الف"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام تیم",
						value: teamA,
						onChange: setTeamA
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بازیکن ۱",
							value: a1,
							onChange: setA1,
							placeholder: "اختیاری"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بازیکن ۲",
							value: a2,
							onChange: setA2,
							placeholder: "اختیاری"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3 flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "تیم ب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام تیم",
						value: teamB,
						onChange: setTeamB
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بازیکن ۱",
							value: b1,
							onChange: setB1,
							placeholder: "اختیاری"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بازیکن ۲",
							value: b2,
							onChange: setB2,
							placeholder: "اختیاری"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3 text-sm leading-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "قانون این بازی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-ink/70",
						children: ruleLine(settings)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 list-disc pe-4 text-xs leading-5 text-ink/80",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "موفقیت معمولی: اعلام ضربدر ۱۰. شکست: همان مقدار منفی." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "اعلام ۱۰: موفقیت ۲۰۰+ و شکست ۲۰۰−، نه ۱۰۰." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "برد از ۵۰۰، فقط بعد از یک اعلام موفقِ دقیقاً ۸." })
						]
					})
				]
			}),
			unfinished > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 flex items-start gap-2 rounded-2xl border border-brass/50 px-3 py-3 text-sm text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1 size-4",
					checked: ack,
					onChange: (e) => setAck(e.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بازی ناتمام قبلی پاک نمی‌شود و در تاریخچه می‌ماند. بازی جدید جدا ساخته می‌شود." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "w-full",
					disabled: locked,
					onClick: () => {
						const id = startGame({
							teamA: {
								name: teamA,
								p1: a1,
								p2: a2
							},
							teamB: {
								name: teamB,
								p1: b1,
								p2: b2
							}
						});
						navigate({
							to: "/play/$gameId",
							params: { gameId: id }
						});
					},
					children: "شروع امتیازدهی"
				})
			})
		]
	});
}
//#endregion
export { NewGame as component };
