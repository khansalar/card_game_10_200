import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, c as faDigits, f as ruleLine, i as Num, n as Card, o as btnClass, p as winnerLabel, r as ConfirmDialog, t as Btn } from "./shell-85x_j55U.mjs";
import { c as useGameStore, i as Route$2, l as deriveGame, s as useGame } from "./router-DWHbFamB.mjs";
import { n as playTone, t as buzz } from "./feedback-Csm43859.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/play._gameId-CS9evUCK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TeamPanel({ side, team, score, positive, negative, qualified, qualifiedAt, warning, blocked, leading, last, points, success }) {
	const pct = Math.max(0, Math.min(100, score / 500 * 100));
	const players = [team.p1, team.p2].filter(Boolean).join(" · ");
	const red = side === "A";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `pip absolute top-2 end-3 text-2xl ${red ? "text-heart/70" : "text-ink/50"}`,
				"aria-hidden": true,
				children: red ? "♥" : "♠"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `pip absolute bottom-2 start-3 text-xl ${red ? "text-heart/40" : "text-ink/30"}`,
				"aria-hidden": true,
				children: red ? "♦" : "♣"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "truncate text-base font-semibold",
						children: team.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-ink/60",
						children: players || "بدون نام بازیکن"
					})]
				}), leading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-brass/20 px-2 py-1 text-xs font-medium text-brass",
					children: "پیش"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-2 text-4xl font-bold tracking-tight ${score < 0 ? "text-heart" : "text-ink"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: score })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 h-1.5 overflow-hidden rounded-full bg-ink/10",
				"aria-hidden": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full bg-chip",
					style: { width: `${pct}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-ink/60",
				children: [
					"تا ۵۰۰: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: Math.max(0, 500 - score) }),
					" امتیاز",
					score >= 500 ? " · از حد گذشت" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 grid grid-cols-2 gap-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-ok/10 px-2 py-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-ink/60",
						children: "امتیاز مثبت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-semibold text-ok",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
							value: positive,
							signed: true
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-heart/10 px-2 py-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-ink/60",
						children: "امتیاز منفی"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-semibold text-heart",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
							value: negative,
							signed: true
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: qualified ? "font-semibold text-ok" : "text-ink/70",
					children: qualified ? `شرط ۸ انجام شد${qualifiedAt ? ` · دست ${faDigits(qualifiedAt)}` : ""}` : "شرط ۸ هنوز انجام نشده"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 rounded-lg border border-line/30 px-2 py-1.5 text-xs",
				children: last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"آخرین دست: اعلام ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: side === "A" ? last.declaredA : last.declaredB }),
					" · گرفته",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: side === "A" ? last.actualA : last.actualB }),
					" ·",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: success ? "text-ok" : "text-heart",
						children: success ? "موفق" : "ناموفق"
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
						value: points,
						signed: true
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ink/60",
					children: "هنوز دستی ثبت نشده"
				})
			}),
			warning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs leading-5 text-heart",
				children: "هشدار: این تیم هنوز شرط برد با اعلام و گرفتن ۸ دست را تکمیل نکرده است."
			}),
			blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs leading-5 font-medium text-heart",
				children: "امتیاز به ۵۰۰ رسیده، اما شرط ۸ کامل نشده و این تیم برنده نیست."
			})
		]
	});
}
function PlayPage() {
	const { gameId } = Route$2.useParams();
	const navigate = useNavigate();
	const game = useGame(gameId);
	const hydrated = useGameStore((s) => s.hydrated);
	const settings = useGameStore((s) => s.settings);
	const undo = useGameStore((s) => s.undo);
	const removeGame = useGameStore((s) => s.removeGame);
	const [askUndo, setAskUndo] = (0, import_react.useState)(false);
	const [askDelete, setAskDelete] = (0, import_react.useState)(false);
	const derived = (0, import_react.useMemo)(() => game ? deriveGame(game.rounds, game.rules) : null, [game]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "میز بازی",
		children: "در حال خواندن…"
	});
	if (!game || !derived) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "بازی پیدا نشد",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: btnClass("solid"),
			children: "خانه"
		})
	});
	const last = derived.rounds[derived.rounds.length - 1];
	const lead = derived.scoreA === derived.scoreB ? null : derived.scoreA > derived.scoreB ? "A" : "B";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "میز بازی",
		eyebrow: ruleLine(game.rules),
		back: true,
		children: [
			derived.winner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 rounded-2xl border border-brass bg-surface px-3 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-brass",
					children: winnerLabel(derived.winner, game.teamA.name, game.teamB.name)
				}), derived.winner === "draw" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-5 text-muted",
					children: "هر دو تیم همزمان به ۵۰۰ با شرط ۸ رسیدند و امتیازشان برابر است. نتیجه تساوی است، نه دو برنده."
				})]
			}),
			(derived.blockedWinA || derived.blockedWinB) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 rounded-2xl border border-heart/50 bg-surface px-3 py-3 text-xs leading-5 text-fg",
				children: "حد ۵۰۰ رد شده اما اعلام موفق ۸ هنوز کامل نیست. تا آن وقت برنده‌ای اعلام نمی‌شود."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamPanel, {
					side: "A",
					team: game.teamA,
					score: derived.scoreA,
					positive: derived.positiveA,
					negative: derived.negativeA,
					qualified: derived.qualifiedA,
					qualifiedAt: derived.qualifiedAAtRound,
					warning: derived.warningA,
					blocked: derived.blockedWinA,
					leading: lead === "A",
					last,
					points: last?.pointsA ?? 0,
					success: last?.successA ?? false
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamPanel, {
					side: "B",
					team: game.teamB,
					score: derived.scoreB,
					positive: derived.positiveB,
					negative: derived.negativeB,
					qualified: derived.qualifiedB,
					qualifiedAt: derived.qualifiedBAtRound,
					warning: derived.warningB,
					blocked: derived.blockedWinB,
					leading: lead === "B",
					last,
					points: last?.pointsB ?? 0,
					success: last?.successB ?? false
				})]
			}),
			lead === null && derived.rounds.length > 0 && !derived.winner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center text-xs text-brass",
				children: "امتیاز دو تیم مساوی است"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [
					derived.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/round/$gameId",
						params: { gameId },
						search: { edit: void 0 },
						className: btnClass("solid", "col-span-2"),
						children: "ثبت نتیجه دست"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "col-span-2 text-center text-xs text-muted",
						children: "بازی بسته است. با واگرد می‌توانید آن را دوباره باز کنید."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "line",
						disabled: !game.rounds.length,
						onClick: () => setAskUndo(true),
						children: "واگرد آخرین دست"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/log/$gameId",
						params: { gameId },
						className: btnClass("line"),
						children: "تاریخچه دست‌ها"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "danger",
						className: "col-span-2",
						onClick: () => setAskDelete(true),
						children: "حذف این بازی"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: askUndo,
				title: "واگرد آخرین دست؟",
				body: "آخرین دست حذف می‌شود و امتیاز هر دو تیم و شرط ۸ از روی دست‌های باقی‌مانده دوباره حساب می‌شود.",
				confirmLabel: "واگرد",
				onClose: () => setAskUndo(false),
				onConfirm: () => {
					undo(gameId);
					playTone("bad", settings.sound);
					buzz(settings.haptic);
					setAskUndo(false);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: askDelete,
				title: "حذف بازی؟",
				body: "این بازی و همه دست‌هایش از همین دستگاه پاک می‌شود. این کار برگشت ندارد.",
				confirmLabel: "حذف",
				danger: true,
				onClose: () => setAskDelete(false),
				onConfirm: () => {
					removeGame(gameId);
					navigate({ to: "/" });
				}
			})
		]
	});
}
//#endregion
export { PlayPage as component };
