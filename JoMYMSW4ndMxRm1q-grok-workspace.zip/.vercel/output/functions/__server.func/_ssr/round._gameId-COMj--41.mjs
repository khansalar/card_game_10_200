import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, c as faDigits, d as issueText, i as Num, n as Card, p as winnerLabel, s as cx, t as Btn } from "./shell-85x_j55U.mjs";
import { c as useGameStore, d as validateRound, l as deriveGame, r as Route$1, s as useGame, u as scoreTeam } from "./router-DWHbFamB.mjs";
import { n as playTone, t as buzz } from "./feedback-Csm43859.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/round._gameId-COMj--41.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RoundPage() {
	const { gameId } = Route$1.useParams();
	const { edit } = Route$1.useSearch();
	const navigate = useNavigate();
	const game = useGame(gameId);
	const hydrated = useGameStore((s) => s.hydrated);
	const settings = useGameStore((s) => s.settings);
	const saveRound = useGameStore((s) => s.saveRound);
	const editRound = useGameStore((s) => s.editRound);
	const [declaredA, setDeclaredA] = (0, import_react.useState)(null);
	const [actualA, setActualA] = (0, import_react.useState)(null);
	const [declaredB, setDeclaredB] = (0, import_react.useState)(null);
	const [actualB, setActualB] = (0, import_react.useState)(null);
	const [phase, setPhase] = (0, import_react.useState)("edit");
	const [roundId, setRoundId] = (0, import_react.useState)(edit ?? null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [seeded, setSeeded] = (0, import_react.useState)(false);
	const lock = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!game || seeded) return;
		if (edit) {
			const found = game.rounds.find((r) => r.id === edit);
			if (found) {
				setDeclaredA(found.declaredA);
				setActualA(found.actualA);
				setDeclaredB(found.declaredB);
				setActualB(found.actualB);
				setRoundId(found.id);
			}
		}
		setSeeded(true);
	}, [
		game,
		edit,
		seeded
	]);
	const ready = declaredA !== null && actualA !== null && declaredB !== null && actualB !== null;
	const draft = ready ? {
		id: roundId ?? "preview",
		declaredA,
		actualA,
		declaredB,
		actualB
	} : null;
	const issues = draft && game ? validateRound(draft, game.rules, edit ? [] : []) : [];
	const editIndex = game && edit ? game.rounds.findIndex((r) => r.id === edit) : -1;
	const notLast = editIndex >= 0 && game ? editIndex < game.rounds.length - 1 : false;
	const preview = (0, import_react.useMemo)(() => {
		if (!game || !draft || issues.length) return null;
		const rounds = edit ? game.rounds.map((r) => r.id === edit ? {
			...draft,
			id: edit
		} : r) : [...game.rounds, draft];
		return deriveGame(rounds, game.rules);
	}, [
		game,
		draft,
		edit,
		issues.length
	]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "ثبت دست",
		children: "در حال خواندن…"
	});
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "بازی پیدا نشد",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "این بازی وجود ندارد."
		})
	});
	const closed = !edit && deriveGame(game.rounds, game.rules).status === "completed";
	const number = editIndex >= 0 ? editIndex + 1 : game.rounds.length + 1;
	const scoreA = draft ? scoreTeam(draft.declaredA, draft.actualA, game.rules.successMode) : null;
	const scoreB = draft ? scoreTeam(draft.declaredB, draft.actualB, game.rules.successMode) : null;
	function submit() {
		if (!draft || !game || lock.current) return;
		lock.current = true;
		setBusy(true);
		const payload = {
			declaredA: draft.declaredA,
			actualA: draft.actualA,
			declaredB: draft.declaredB,
			actualB: draft.actualB
		};
		const id = roundId ?? crypto.randomUUID();
		const result = edit ? editRound(game.id, edit, payload) : saveRound(game.id, {
			id,
			...payload
		});
		if (!result.ok) {
			lock.current = false;
			setBusy(false);
			setError(issueText(result.issues));
			return;
		}
		const done = deriveGame(useGameStore.getState().games.find((g) => g.id === game.id)?.rounds ?? [], game.rules);
		playTone(done.winner ? "win" : "ok", settings.sound);
		buzz(settings.haptic, done.winner ? [
			20,
			40,
			20
		] : 12);
		navigate({
			to: "/play/$gameId",
			params: { gameId: game.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: edit ? `ویرایش دست ${faDigits(number)}` : `دست ${faDigits(number)}`,
		eyebrow: game.teamA.name + " · " + game.teamB.name,
		back: true,
		footer: phase === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			className: "w-full",
			disabled: !ready || issues.length > 0 || closed,
			onClick: () => {
				if (!edit) setRoundId(crypto.randomUUID());
				setError("");
				setPhase("confirm");
			},
			children: "پیش‌نمایش و تأیید"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "line",
				className: "flex-1",
				onClick: () => setPhase("edit"),
				children: "اصلاح"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "flex-1",
				disabled: busy,
				onClick: submit,
				children: busy ? "در حال ثبت…" : "ثبت نهایی"
			})]
		}),
		children: [closed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-heart",
			children: "این بازی تمام شده. تا واگرد آخرین دست، دست تازه ثبت نمی‌شود."
		}), phase === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamEntry, {
					name: game.teamA.name,
					suit: "♥",
					declared: declaredA,
					actual: actualA,
					maxActual: game.rules.tricksPerRound,
					mode: game.rules.successMode,
					onDeclared: setDeclaredA,
					onActual: setActualA
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamEntry, {
					name: game.teamB.name,
					suit: "♠",
					declared: declaredB,
					actual: actualB,
					maxActual: game.rules.tricksPerRound,
					mode: game.rules.successMode,
					onDeclared: setDeclaredB,
					onActual: setActualB
				}),
				issues.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-heart",
					children: issueText(issues)
				}),
				notLast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-5 text-brass",
					children: "این دست آخرین دست نیست. بعد از ذخیره، امتیاز همه دست‌های بعدی و شرط ۸ دوباره حساب می‌شود. اعداد اعلام و گرفته‌شدهٔ دست‌های دیگر دست نمی‌خورد."
				})
			]
		}) : draft && scoreA && scoreB && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "خلاصه قبل از ثبت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
						name: game.teamA.name,
						declared: draft.declaredA,
						actual: draft.actualA,
						points: scoreA.points,
						success: scoreA.success,
						qual: scoreA.earnedQualification && !deriveGame(edit ? game.rounds.slice(0, editIndex) : game.rounds, game.rules).qualifiedA
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
						name: game.teamB.name,
						declared: draft.declaredB,
						actual: draft.actualB,
						points: scoreB.points,
						success: scoreB.success,
						qual: scoreB.earnedQualification && !deriveGame(edit ? game.rounds.slice(0, editIndex) : game.rounds, game.rules).qualifiedB
					})
				] }),
				preview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"امتیاز بعد از این دست: ",
							game.teamA.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: preview.scoreA }),
							" · ",
							game.teamB.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: preview.scoreB })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-ink/70",
						children: ["حد برد: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: 500 })]
					}),
					(preview.warningA || preview.warningB || preview.blockedWinA || preview.blockedWinB) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs leading-5 text-heart",
						children: ["هشدار: تیمی که بالای ۴۰۰ است و هنوز اعلام موفق ۸ ندارد، برنده حساب نمی‌شود.", (preview.blockedWinA || preview.blockedWinB) && " حد ۵۰۰ رد شده اما شرط ۸ مانده است."]
					}),
					preview.winner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm font-semibold text-ok",
						children: ["با این ثبت، بازی تمام می‌شود. ", winnerLabel(preview.winner, game.teamA.name, game.teamB.name)]
					})
				] }),
				(draft.declaredA === 10 || draft.declaredB === 10) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-brass",
					children: "قانون ۱۰: به‌جای ۱۰۰، نتیجه ۲۰۰+ یا ۲۰۰− است."
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-heart",
					children: error
				})
			]
		})]
	});
}
function TeamEntry({ name, suit, declared, actual, maxActual, mode, onDeclared, onActual }) {
	const scored = declared !== null && actual !== null ? scoreTeam(declared, actual, mode) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-sm font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pip me-1 text-heart",
					"aria-hidden": true,
					children: suit
				}), name]
			}), scored && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: scored.success ? "text-xs font-semibold text-ok" : "text-xs font-semibold text-heart",
				children: [
					scored.success ? "موفق" : "ناموفق",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
						value: scored.points,
						signed: true
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Picker, {
			label: "اعلام",
			max: 10,
			value: declared,
			onChange: onDeclared
		}),
		declared === 10 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-brass",
			children: "اعلام ۱۰: موفقیت ۲۰۰+ و شکست ۲۰۰−."
		}),
		declared === 8 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-brass",
			children: "اعلام ۸ و موفقیت، شرط لازم برد را کامل می‌کند و ۸۰ امتیاز دارد."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Picker, {
				label: "گرفته",
				max: maxActual,
				value: actual,
				onChange: onActual
			})
		})
	] });
}
function Picker({ label, max, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "mb-1 text-xs text-ink/70",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-6 gap-1.5",
		children: Array.from({ length: max + 1 }, (_, n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": value === n,
			onClick: () => onChange(n),
			className: cx("min-h-11 rounded-lg border text-sm font-semibold", value === n ? "border-chip bg-chip text-card" : "border-line/40 text-ink"),
			children: faDigits(n)
		}, n))
	})] });
}
function SummaryRow({ name, declared, actual, points, success, qual }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-2 text-sm leading-6",
		children: [
			name,
			": اعلام ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: declared }),
			"، گرفته ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: actual }),
			"،",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: success ? "text-ok" : "text-heart",
				children: success ? "موفق" : "ناموفق"
			}),
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
				value: points,
				signed: true
			}),
			qual ? " · شرط ۸ با این دست کامل می‌شود" : ""
		]
	});
}
//#endregion
export { RoundPage as component };
