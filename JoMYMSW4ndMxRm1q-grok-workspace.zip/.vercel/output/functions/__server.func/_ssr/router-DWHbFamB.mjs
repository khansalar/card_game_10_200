import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DWHbFamB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function defaultRules(partial) {
	const tricks = partial?.tricksPerRound;
	const trickValidation = partial?.trickValidation;
	const successMode = partial?.successMode;
	return {
		tricksPerRound: typeof tricks === "number" && Number.isInteger(tricks) && tricks >= 1 && tricks <= 26 ? tricks : 13,
		trickValidation: trickValidation === "off" || trickValidation === "exact" || trickValidation === "atMost" ? trickValidation : "exact",
		successMode: successMode === "exact" || successMode === "atLeast" ? successMode : "atLeast"
	};
}
function isSuccessful(declared, actual, mode) {
	return mode === "exact" ? actual === declared : actual >= declared;
}
/** Points for one team. Does not validate ranges — callers validate first. */
function scoreTeam(declared, actual, mode = "atLeast") {
	const success = isSuccessful(declared, actual, mode);
	const isSpecialTen = declared === 10;
	const magnitude = isSpecialTen ? 200 : declared * 10;
	return {
		points: success ? magnitude : -magnitude,
		success,
		earnedQualification: declared === 8 && success,
		isSpecialTen
	};
}
function needsWarning(score, qualified) {
	return score > 400 && !qualified;
}
function isEligible(score, qualified) {
	return score >= 500 && qualified;
}
function blockedByQualification(score, qualified) {
	return score >= 500 && !qualified;
}
/**
* Deterministic winner.
* Higher score wins if both are eligible. Equal eligible scores are a draw.
*/
function resolveWinner(scoreA, qualifiedA, scoreB, qualifiedB) {
	const a = isEligible(scoreA, qualifiedA);
	const b = isEligible(scoreB, qualifiedB);
	if (a && !b) return "A";
	if (b && !a) return "B";
	if (a && b) {
		if (scoreA > scoreB) return "A";
		if (scoreB > scoreA) return "B";
		return "draw";
	}
	return null;
}
function validateRound(input, rules, existingIds = []) {
	const issues = [];
	const cfg = defaultRules(rules);
	const declared = [input.declaredA, input.declaredB];
	const actual = [input.actualA, input.actualB];
	if (declared.some((d) => !Number.isInteger(d) || d < 0 || d > 10)) issues.push("declared-range");
	if (actual.some((a) => !Number.isInteger(a) || a < 0 || a > cfg.tricksPerRound)) issues.push("actual-range");
	if (!issues.includes("actual-range") && !issues.includes("declared-range")) {
		const sum = input.actualA + input.actualB;
		if (cfg.trickValidation === "exact" && sum !== cfg.tricksPerRound) issues.push("sum-exact");
		if (cfg.trickValidation === "atMost" && sum > cfg.tricksPerRound) issues.push("sum-at-most");
	}
	if ("id" in input && input.id && existingIds.includes(input.id)) issues.push("duplicate");
	return issues;
}
function deriveGame(rounds, rules) {
	const mode = defaultRules(rules).successMode;
	let scoreA = 0;
	let scoreB = 0;
	let positiveA = 0;
	let negativeA = 0;
	let positiveB = 0;
	let negativeB = 0;
	let qualifiedA = false;
	let qualifiedB = false;
	let qualifiedAAtRound = null;
	let qualifiedBAtRound = null;
	const records = [];
	rounds.forEach((round, index) => {
		const a = scoreTeam(round.declaredA, round.actualA, mode);
		const b = scoreTeam(round.declaredB, round.actualB, mode);
		scoreA += a.points;
		scoreB += b.points;
		if (a.points > 0) positiveA += a.points;
		if (a.points < 0) negativeA += a.points;
		if (b.points > 0) positiveB += b.points;
		if (b.points < 0) negativeB += b.points;
		const earnedA = a.earnedQualification && !qualifiedA;
		const earnedB = b.earnedQualification && !qualifiedB;
		if (earnedA) {
			qualifiedA = true;
			qualifiedAAtRound = index + 1;
		}
		if (earnedB) {
			qualifiedB = true;
			qualifiedBAtRound = index + 1;
		}
		records.push({
			id: round.id,
			number: index + 1,
			declaredA: round.declaredA,
			actualA: round.actualA,
			declaredB: round.declaredB,
			actualB: round.actualB,
			pointsA: a.points,
			pointsB: b.points,
			successA: a.success,
			successB: b.success,
			earnedQualificationA: earnedA,
			earnedQualificationB: earnedB,
			cumulativeA: scoreA,
			cumulativeB: scoreB,
			qualifiedA,
			qualifiedB,
			warningA: needsWarning(scoreA, qualifiedA),
			warningB: needsWarning(scoreB, qualifiedB),
			blockedWinA: blockedByQualification(scoreA, qualifiedA),
			blockedWinB: blockedByQualification(scoreB, qualifiedB)
		});
	});
	const winner = resolveWinner(scoreA, qualifiedA, scoreB, qualifiedB);
	const last = records[records.length - 1];
	return {
		rounds: records,
		scoreA,
		scoreB,
		positiveA,
		negativeA,
		positiveB,
		negativeB,
		qualifiedA,
		qualifiedB,
		qualifiedAAtRound,
		qualifiedBAtRound,
		warningA: last ? last.warningA : false,
		warningB: last ? last.warningB : false,
		blockedWinA: blockedByQualification(scoreA, qualifiedA),
		blockedWinB: blockedByQualification(scoreB, qualifiedB),
		winner,
		status: winner ? "completed" : "active"
	};
}
function appendRound(rounds, next, rules) {
	const issues = validateRound(next, rules, rounds.map((r) => r.id));
	if (issues.length) return {
		ok: false,
		issues
	};
	return {
		ok: true,
		rounds: [...rounds, next]
	};
}
function undoLast(rounds) {
	return rounds.slice(0, -1);
}
function replaceRound(rounds, roundId, next, rules) {
	const index = rounds.findIndex((r) => r.id === roundId);
	if (index < 0) return {
		ok: false,
		issues: ["missing"]
	};
	const candidate = {
		id: roundId,
		...next
	};
	const issues = validateRound(candidate, rules, []);
	if (issues.length) return {
		ok: false,
		issues
	};
	const copy = rounds.slice();
	copy[index] = candidate;
	return {
		ok: true,
		rounds: copy
	};
}
function isStoredRound(value) {
	if (!value || typeof value !== "object") return false;
	const r = value;
	return typeof r.id === "string" && r.id.length > 0 && r.id.length < 80 && Number.isInteger(r.declaredA) && Number.isInteger(r.actualA) && Number.isInteger(r.declaredB) && Number.isInteger(r.actualB) && r.declaredA >= 0 && r.declaredA <= 10 && r.declaredB >= 0 && r.declaredB <= 10 && r.actualA >= 0 && r.actualA <= 26 && r.actualB >= 0 && r.actualB <= 26;
}
/** Drop corrupt rounds. Keeps order. Re-derivation fixes totals. */
function sanitizeRounds(value) {
	if (!Array.isArray(value)) return [];
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const item of value) {
		if (!isStoredRound(item) || seen.has(item.id)) continue;
		seen.add(item.id);
		out.push({
			id: item.id,
			declaredA: item.declaredA,
			actualA: item.actualA,
			declaredB: item.declaredB,
			actualB: item.actualB
		});
	}
	return out;
}
var DEFAULT_SETTINGS = {
	tricksPerRound: 13,
	trickValidation: "exact",
	successMode: "atLeast",
	sound: true,
	haptic: true,
	theme: "dark"
};
function clip(value, fallback) {
	return ((typeof value === "string" ? value.trim() : "") || fallback).slice(0, 40);
}
function cleanTeam(value, fallback) {
	const t = value ?? {};
	return {
		name: clip(t.name, fallback),
		p1: typeof t.p1 === "string" ? t.p1.trim().slice(0, 40) : "",
		p2: typeof t.p2 === "string" ? t.p2.trim().slice(0, 40) : ""
	};
}
function cleanSettings(value) {
	const s = value ?? {};
	return {
		...defaultRules({
			tricksPerRound: s.tricksPerRound,
			trickValidation: s.trickValidation,
			successMode: s.successMode
		}),
		sound: s.sound !== false,
		haptic: s.haptic !== false,
		theme: s.theme === "light" ? "light" : "dark"
	};
}
function cleanGame(value) {
	if (!value || typeof value !== "object") return null;
	const g = value;
	if (typeof g.id !== "string" || !g.id) return null;
	return {
		id: g.id.slice(0, 80),
		createdAt: typeof g.createdAt === "string" ? g.createdAt : (/* @__PURE__ */ new Date(0)).toISOString(),
		updatedAt: typeof g.updatedAt === "string" ? g.updatedAt : (/* @__PURE__ */ new Date(0)).toISOString(),
		teamA: cleanTeam(g.teamA, "تیم الف"),
		teamB: cleanTeam(g.teamB, "تیم ب"),
		rounds: sanitizeRounds(g.rounds),
		rules: defaultRules(g.rules)
	};
}
function uid() {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
	return `id-${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`;
}
function touch(game, rounds) {
	return {
		...game,
		rounds,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function applyTheme(theme) {
	if (typeof document === "undefined") return;
	document.documentElement.dataset.theme = theme;
	document.documentElement.style.colorScheme = theme;
}
var useGameStore = create()(persist((set, get) => ({
	settings: DEFAULT_SETTINGS,
	games: [],
	activeGameId: null,
	hydrated: false,
	startGame: (input) => {
		const id = uid();
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const { settings } = get();
		set({
			games: [{
				id,
				createdAt: now,
				updatedAt: now,
				teamA: cleanTeam(input.teamA, "تیم الف"),
				teamB: cleanTeam(input.teamB, "تیم ب"),
				rounds: [],
				rules: defaultRules(settings)
			}, ...get().games],
			activeGameId: id
		});
		return id;
	},
	saveRound: (gameId, round) => {
		const game = get().games.find((g) => g.id === gameId);
		if (!game) return {
			ok: false,
			issues: ["missing"]
		};
		if (deriveGame(game.rounds, game.rules).status === "completed") return {
			ok: false,
			issues: ["closed"]
		};
		const result = appendRound(game.rounds, round, game.rules);
		if (!result.ok) return result;
		set({
			games: get().games.map((g) => g.id === gameId ? touch(g, result.rounds) : g),
			activeGameId: gameId
		});
		return { ok: true };
	},
	editRound: (gameId, roundId, next) => {
		const game = get().games.find((g) => g.id === gameId);
		if (!game) return {
			ok: false,
			issues: ["missing"]
		};
		const result = replaceRound(game.rounds, roundId, next, game.rules);
		if (!result.ok) return result;
		set({ games: get().games.map((g) => g.id === gameId ? touch(g, result.rounds) : g) });
		return { ok: true };
	},
	undo: (gameId) => {
		const game = get().games.find((g) => g.id === gameId);
		if (!game || game.rounds.length === 0) return false;
		const rounds = undoLast(game.rounds);
		set({ games: get().games.map((g) => g.id === gameId ? touch(g, rounds) : g) });
		return true;
	},
	removeGame: (gameId) => {
		set({
			games: get().games.filter((g) => g.id !== gameId),
			activeGameId: get().activeGameId === gameId ? null : get().activeGameId
		});
	},
	updateSettings: (partial) => {
		const settings = cleanSettings({
			...get().settings,
			...partial
		});
		set({ settings });
		applyTheme(settings.theme);
	}
}), {
	name: "dah-dovist-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		settings: state.settings,
		games: state.games,
		activeGameId: state.activeGameId
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		const games = Array.isArray(p.games) ? p.games.map(cleanGame).filter((g) => g !== null) : [];
		const active = typeof p.activeGameId === "string" && games.some((g) => g.id === p.activeGameId) ? p.activeGameId : null;
		return {
			...current,
			settings: cleanSettings(p.settings),
			games,
			activeGameId: active
		};
	},
	onRehydrateStorage: () => () => {
		const theme = useGameStore.getState().settings.theme;
		applyTheme(theme);
		useGameStore.setState({ hydrated: true });
	}
}));
function useGame(id) {
	return useGameStore((s) => s.games.find((g) => g.id === id));
}
function latestUnfinished(games) {
	return [...games].filter((g) => deriveGame(g.rounds, g.rules).status === "active").sort((a, b) => a.updatedAt < b.updatedAt ? 1 : -1)[0];
}
var styles_default = "/assets/styles-Da-BlCqe.css";
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ده دویست" },
			{
				name: "description",
				content: "برگه امتیاز بازی کارتی ده دویست برای دو تیم"
			},
			{
				name: "theme-color",
				content: "#0e3b2e"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap"
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	(0, import_react.useEffect)(() => {
		useGameStore.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fa",
		dir: "rtl",
		"data-theme": "dark",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$9 = () => import("./routes-XOfddBu-.mjs");
var Route$9 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./about-1R-BTFQg.mjs");
var Route$8 = createFileRoute("/about")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./archive-ByKzteq0.mjs");
var Route$7 = createFileRoute("/archive")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./new-k4nvN7tH.mjs");
var Route$6 = createFileRoute("/new")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./rules-9mayphax.mjs");
var Route$5 = createFileRoute("/rules")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./settings-BrJoUJz9.mjs");
var Route$4 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./log._gameId-DgLDfEmb.mjs");
var Route$3 = createFileRoute("/log/$gameId")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./play._gameId-CS9evUCK.mjs");
var Route$2 = createFileRoute("/play/$gameId")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./round._gameId-COMj--41.mjs");
var Route$1 = createFileRoute("/round/$gameId")({
	validateSearch: (search) => ({ edit: typeof search.edit === "string" ? search.edit : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./detail._gameId._roundId-DTfxP115.mjs");
var Route = createFileRoute("/detail/$gameId/$roundId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$9.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$10
	}),
	AboutRoute: Route$8.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$10
	}),
	ArchiveRoute: Route$7.update({
		id: "/archive",
		path: "/archive",
		getParentRoute: () => Route$10
	}),
	NewRoute: Route$6.update({
		id: "/new",
		path: "/new",
		getParentRoute: () => Route$10
	}),
	RulesRoute: Route$5.update({
		id: "/rules",
		path: "/rules",
		getParentRoute: () => Route$10
	}),
	SettingsRoute: Route$4.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$10
	}),
	LogGameIdRoute: Route$3.update({
		id: "/log/$gameId",
		path: "/log/$gameId",
		getParentRoute: () => Route$10
	}),
	PlayGameIdRoute: Route$2.update({
		id: "/play/$gameId",
		path: "/play/$gameId",
		getParentRoute: () => Route$10
	}),
	RoundGameIdRoute: Route$1.update({
		id: "/round/$gameId",
		path: "/round/$gameId",
		getParentRoute: () => Route$10
	}),
	DetailGameIdRoundIdRoute: Route.update({
		id: "/detail/$gameId/$roundId",
		path: "/detail/$gameId/$roundId",
		getParentRoute: () => Route$10
	})
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$3 as a, useGameStore as c, validateRound as d, Route$2 as i, deriveGame as l, Route as n, latestUnfinished as o, Route$1 as r, useGame as s, router_exports as t, scoreTeam as u };
