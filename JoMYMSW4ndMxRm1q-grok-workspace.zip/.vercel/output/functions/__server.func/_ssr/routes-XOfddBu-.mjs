import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Num, o as btnClass, p as winnerLabel, u as faWhen } from "./shell-85x_j55U.mjs";
import { c as useGameStore, l as deriveGame, o as latestUnfinished } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-XOfddBu-.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const hydrated = useGameStore((s) => s.hydrated);
	const games = useGameStore((s) => s.games);
	const resume = hydrated ? latestUnfinished(games) : void 0;
	const recent = hydrated ? [...games].sort((a, b) => a.updatedAt < b.updatedAt ? 1 : -1).slice(0, 3) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "felt relative min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 overflow-hidden",
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pip absolute -top-4 start-2 text-8xl text-fg/10",
				children: "♠"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pip absolute top-28 end-0 text-7xl text-heart/20",
				children: "♥"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "relative mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-brass",
					children: "DAH-DOVIST"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-4xl font-bold text-fg",
					children: "ده دویست"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xs text-sm leading-6 text-muted",
					children: "برگه امتیاز دو تیم. اعلام هر دست، حساب ۱۰ برابر، و برد با ۵۰۰ به‌شرط گرفتن ۸."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid grid-cols-4 gap-2",
					"aria-hidden": true,
					children: [
						["♠", false],
						["♥", true],
						["♦", true],
						["♣", false]
					].map(([suit, red]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `pip flex h-16 items-center justify-center rounded-xl bg-card text-3xl shadow-sm ${red ? "text-heart" : "text-ink"}`,
						children: suit
					}, String(suit)))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/new",
						className: btnClass("solid"),
						children: "شروع بازی جدید"
					}), resume && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/play/$gameId",
						params: { gameId: resume.id },
						className: btnClass("line"),
						children: [
							"ادامه بازی · ",
							resume.teamA.name,
							" و ",
							resume.teamB.name
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold text-fg",
								children: "تاریخچه بازی‌ها"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/archive",
								className: "text-xs text-brass",
								children: "همه"
							})]
						}),
						!hydrated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "در حال خواندن بازی‌های ذخیره‌شده…"
						}),
						hydrated && recent.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-2xl border border-line/30 px-3 py-4 text-sm text-muted",
							children: "هنوز بازی‌ای ذخیره نشده. اولین دست را شروع کنید."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-2",
							children: recent.map((game) => {
								const d = deriveGame(game.rounds, game.rules);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/play/$gameId",
									params: { gameId: game.id },
									className: "block rounded-2xl bg-surface px-3 py-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center justify-between gap-2 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "truncate font-medium",
												children: [
													game.teamA.name,
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted",
														children: "مقابل"
													}),
													" ",
													game.teamB.name
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "shrink-0 text-xs text-brass",
												children: d.status === "completed" ? "تمام" : "ناتمام"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-1 flex items-center justify-between text-xs text-muted",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: d.scoreA }),
												" — ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: d.scoreB })
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: faWhen(game.updatedAt) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-xs text-fg/80",
											children: winnerLabel(d.winner, game.teamA.name, game.teamB.name)
										})
									]
								}) }, game.id);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mt-auto flex justify-center gap-4 pt-8 text-sm text-brass",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/rules",
							children: "قوانین"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							children: "تنظیمات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							children: "درباره"
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { Home as component };
