import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, i as Num, l as faSigned, n as Card } from "./shell-85x_j55U.mjs";
import { c as useGameStore, u as scoreTeam } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rules-9mayphax.js
var import_jsx_runtime = require_jsx_runtime();
function RulesPage() {
	const mode = useGameStore((s) => s.settings.successMode);
	const rows = Array.from({ length: 11 }, (_, declared) => {
		return {
			declared,
			success: scoreTeam(declared, declared, mode).points,
			fail: declared === 0 && mode === "atLeast" ? null : scoreTeam(declared, Math.max(0, declared - 1), mode).points
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "قوانین",
		eyebrow: "ده دویست",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 text-sm leading-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "امتیاز هر دست"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-ink/80",
					children: "اگر تیم به اعلامش برسد، امتیازش اعلام ضربدر ۱۰ است. اگر نرسد، همان مقدار منفی می‌شود. رسیدن یعنی تعداد دست گرفته‌شده از اعلام کمتر نباشد، مگر اینکه در تنظیمات «تعداد دقیق» را انتخاب کرده باشید."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "اعلام ۱۰"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-ink/80",
					children: "اعلام ۱۰ حالت خاص است: موفقیت ۲۰۰+ و شکست ۲۰۰−. هرگز ۱۰۰ امتیاز حساب نمی‌شود."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "شرط برد با ۸"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-ink/80",
					children: "تیم وقتی می‌تواند برنده شود که یک بار دقیقاً ۸ اعلام کرده و آن اعلام موفق بوده باشد. این یک شرط جداست، نه فقط ۸۰ امتیاز. اعلام ناموفق ۸، هشتاد امتیاز منفی دارد و شرط را کامل نمی‌کند. اگر تیمی ۸ دست بگیرد ولی عدد دیگری اعلام کرده باشد، شرط انجام نشده است."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "۵۰۰ و هشدار بالای ۴۰۰"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-ink/80",
						children: "برنده تیمی است که امتیازش به ۵۰۰ یا بیشتر برسد و شرط ۸ را هم داشته باشد. اگر امتیاز از ۴۰۰ بیشتر شود و شرط ۸ مانده باشد، هشدار می‌ماند. خود ۴۰۰ هشدار ندارد. رسیدن به ۵۰۰ بدون شرط ۸ برنده نمی‌سازد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-heart",
						children: "هشدار: این تیم هنوز شرط برد با اعلام و گرفتن ۸ دست را تکمیل نکرده است."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "اگر هر دو تیم با هم به برد برسند"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-ink/80",
					children: "فقط یک نتیجه اعلام می‌شود. امتیاز بالاتر برنده است. اگر امتیاز برابر باشد، بازی با تساوی تمام می‌شود و هیچ تیمی به‌تنهایی برنده نیست."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "overflow-x-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: "جدول ۰ تا ۱۰"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-ink/60",
							children: ["حالت فعلی موفقیت: ", mode === "exact" ? "دقیقاً برابر اعلام" : "حداقل به اندازهٔ اعلام"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "mt-2 w-full text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-ink/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-start font-medium",
										children: "اعلام"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-start font-medium",
										children: "موفق"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-start font-medium",
										children: "ناموفق"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-ink/10",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, { value: row.declared }),
											row.declared === 8 ? " · شرط" : "",
											row.declared === 10 ? " · خاص" : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-ok",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("bdi", {
											dir: "ltr",
											children: faSigned(row.success)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-heart",
										children: row.fail === null ? "—" : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("bdi", {
											dir: "ltr",
											children: faSigned(row.fail)
										})
									})
								]
							}, row.declared)) })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "فرض‌هایی که در خود بازی مشخص شده"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-1 list-disc pe-4 text-xs leading-5 text-ink/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "اعلام از ۰ تا ۱۰ است و برنامه آن را خودش عوض نمی‌کند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "تعداد دست هر دور پیش‌فرض ۱۳ است و از ۱ تا ۲۶ در تنظیمات عوض می‌شود." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "مجموع دست‌های گرفته‌شده می‌تواند دقیقاً برابر، حداکثر، یا بدون قید باشد." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "دست اضافه در حالت «حداقل» امتیاز جدا ندارد؛ فقط اعلام را موفق می‌کند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "اعلام ۰ در حالت حداقل همیشه موفق است و صفر امتیاز دارد." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "واگرد، آخرین دست را برمی‌دارد. ویرایش دست قدیمی جمع‌های بعدی را از نو می‌سازد." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "تنظیمات تازه، قانون بازی‌های قبلی را عوض نمی‌کند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "همه‌چیز روی همین دستگاه می‌ماند و به اینترنت نیاز ندارد." })
					]
				})] })
			]
		})
	});
}
//#endregion
export { RulesPage as component };
