import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Page, c as faDigits, f as ruleLine, n as Card } from "./shell-85x_j55U.mjs";
import { c as useGameStore } from "./router-DWHbFamB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-BrJoUJz9.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const settings = useGameStore((s) => s.settings);
	const update = useGameStore((s) => s.updateSettings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "تنظیمات",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "تعداد دست هر دور"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-ink/70",
						children: "برای بازی‌های تازه قفل می‌شود. بازی‌های ساخته‌شده قانون خودشان را نگه می‌دارند."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "size-11 rounded-full border border-line/50 text-lg",
								"aria-label": "کم کردن",
								onClick: () => update({ tricksPerRound: Math.max(1, settings.tricksPerRound - 1) }),
								children: "−"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-2xl font-bold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("bdi", {
									dir: "ltr",
									children: faDigits(settings.tricksPerRound)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "size-11 rounded-full border border-line/50 text-lg",
								"aria-label": "زیاد کردن",
								onClick: () => update({ tricksPerRound: Math.min(26, settings.tricksPerRound + 1) }),
								children: "+"
							})
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "اعتبار مجموع دست‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							on: settings.trickValidation === "exact",
							label: "دقیقاً",
							onClick: () => update({ trickValidation: "exact" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							on: settings.trickValidation === "atMost",
							label: "حداکثر",
							onClick: () => update({ trickValidation: "atMost" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							on: settings.trickValidation === "off",
							label: "خاموش",
							onClick: () => update({ trickValidation: "off" })
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "معنی موفقیت اعلام"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							on: settings.successMode === "atLeast",
							label: "حداقل اعلام",
							onClick: () => update({ successMode: "atLeast" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							on: settings.successMode === "exact",
							label: "دقیقاً برابر",
							onClick: () => update({ successMode: "exact" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-5 text-ink/70",
						children: "پیش‌فرض «حداقل» است: دست بیشتر از اعلام هم موفقیت است و امتیاز اضافه ندارد. «دقیقاً» یعنی دست اضافه هم شکست است."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					label: "صدای نتیجه",
					on: settings.sound,
					onClick: () => update({ sound: !settings.sound })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					label: "لرزش کوتاه",
					on: settings.haptic,
					onClick: () => update({ haptic: !settings.haptic })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "ظاهر"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						on: settings.theme === "dark",
						label: "میز تیره",
						onClick: () => update({ theme: "dark" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						on: settings.theme === "light",
						label: "میز روشن",
						onClick: () => update({ theme: "light" })
					})]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs leading-5 text-muted",
					children: ["قانون بازی بعدی: ", ruleLine(settings)]
				})
			]
		})
	});
}
function Choice({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `min-h-11 rounded-xl border text-xs font-semibold ${on ? "border-chip bg-chip text-card" : "border-line/40 text-ink"}`,
		children: label
	});
}
function Toggle({ label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex min-h-11 w-full items-center justify-between text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `rounded-full px-2 py-1 text-xs ${on ? "bg-ok/15 text-ok" : "bg-ink/10 text-ink/60"}`,
			children: on ? "روشن" : "خاموش"
		})]
	});
}
//#endregion
export { SettingsPage as component };
