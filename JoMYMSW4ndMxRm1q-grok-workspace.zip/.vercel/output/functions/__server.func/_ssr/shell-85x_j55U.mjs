import { S as require_jsx_runtime, x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-85x_j55U.js
var import_jsx_runtime = require_jsx_runtime();
var FA = "۰۱۲۳۴۵۶۷۸۹";
function faDigits(value) {
	return String(value).replace(/\d/g, (d) => FA[Number(d)] ?? d);
}
function faSigned(n) {
	if (n > 0) return `+${faDigits(n)}`;
	if (n < 0) return `−${faDigits(Math.abs(n))}`;
	return faDigits(0);
}
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
var ISSUE_TEXT = {
	"declared-range": "اعلام باید عددی از ۰ تا ۱۰ باشد.",
	"actual-range": "دست‌های گرفته‌شده خارج از محدودهٔ این دور است.",
	"sum-exact": "مجموع دست‌های دو تیم با تعداد دست‌های دور یکی نیست.",
	"sum-at-most": "مجموع دست‌های دو تیم از تعداد دست‌های دور بیشتر است.",
	duplicate: "این دست قبلاً ثبت شده است.",
	missing: "این دست در تاریخچه پیدا نشد.",
	closed: "این بازی تمام شده است. برای ثبت دست تازه، آخرین دست را واگرد کنید."
};
function issueText(issues) {
	return issues.map((i) => ISSUE_TEXT[i]).join(" ");
}
function faWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	return new Intl.DateTimeFormat("fa-IR", {
		month: "short",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	}).format(date);
}
function winnerLabel(winner, nameA, nameB) {
	if (winner === "A") return `${nameA} برنده شد`;
	if (winner === "B") return `${nameB} برنده شد`;
	if (winner === "draw") return "تساوی — هیچ‌کدام به‌تنهایی برنده نیستند";
	return "بازی ادامه دارد";
}
function ruleLine(rules) {
	return `${rules.trickValidation === "exact" ? `مجموع دست‌ها دقیقاً ${faDigits(rules.tricksPerRound)}` : rules.trickValidation === "atMost" ? `مجموع دست‌ها حداکثر ${faDigits(rules.tricksPerRound)}` : `بدون قید مجموع، هر تیم ۰ تا ${faDigits(rules.tricksPerRound)}`} · ${rules.successMode === "exact" ? "موفقیت فقط با تعداد دقیق" : "موفقیت با حداقل اعلام"}`;
}
function Page({ title, eyebrow, back, children, footer }) {
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "felt relative min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuitField, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-dvh w-full max-w-md flex-col px-4 py-5",
			children: [
				(back || title) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-4 flex items-center gap-3",
					children: [back && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => router.history.back(),
						className: "flex size-11 items-center justify-center rounded-full border border-line/50 text-fg",
						"aria-label": "بازگشت",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "text-lg",
							children: "→"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-brass",
							children: eyebrow
						}), title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-xl font-semibold text-fg",
							children: title
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-1 flex-col",
					children
				}),
				footer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: footer
				})
			]
		})]
	});
}
function SuitField() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pip absolute -top-2 start-3 text-7xl text-fg/10",
				children: "♠"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pip absolute top-24 end-2 text-6xl text-heart/20",
				children: "♥"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pip absolute bottom-16 start-6 text-6xl text-heart/15",
				children: "♦"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pip absolute -bottom-3 end-4 text-7xl text-fg/10",
				children: "♣"
			})
		]
	});
}
function btnClass(variant = "solid", className) {
	return cx("inline-flex min-h-11 items-center justify-center rounded-xl px-4 text-center text-sm font-semibold transition-opacity disabled:opacity-40", variant === "solid" && "bg-card text-ink", variant === "line" && "border border-line/70 bg-transparent text-fg", variant === "quiet" && "bg-transparent text-muted", variant === "danger" && "border border-heart/40 bg-transparent text-heart", variant === "green" && "bg-chip text-card", className);
}
function Btn({ variant = "solid", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: btnClass(variant, className),
		...props
	});
}
function Num({ value, signed = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("bdi", {
		dir: "ltr",
		className: "tabular-nums",
		children: signed ? faSigned(value) : faDigits(value)
	});
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cx("rounded-2xl bg-card px-4 py-3 text-ink shadow-sm", className),
		children
	});
}
function ConfirmDialog({ open, title, body, confirmLabel, danger, onConfirm, onClose }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-4 sm:items-center",
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "confirm-title",
			className: "w-full max-w-md rounded-2xl bg-card p-4 text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "confirm-title",
					className: "text-base font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-6 text-ink/80",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "quiet",
						className: "flex-1 text-ink",
						onClick: onClose,
						children: "انصراف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: danger ? "danger" : "green",
						className: "flex-1",
						onClick: onConfirm,
						children: confirmLabel
					})]
				})
			]
		})
	});
}
//#endregion
export { Page as a, faDigits as c, issueText as d, ruleLine as f, Num as i, faSigned as l, Card as n, btnClass as o, winnerLabel as p, ConfirmDialog as r, cx as s, Btn as t, faWhen as u };
