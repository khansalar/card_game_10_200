//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DLhKa3BC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/archive",
			"/new",
			"/rules",
			"/settings",
			"/log/$gameId",
			"/play/$gameId",
			"/round/$gameId",
			"/detail/$gameId/$roundId"
		],
		preloads: [
			"/assets/index-C6bfuQp2.js",
			"/assets/useRouter-BOAPZDg1.js",
			"/assets/preload-helper-CHSrT7WI.js",
			"/assets/link-CZjQONK7.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C6bfuQp2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-FEnmhWWz.js", "/assets/shell-Dr4FHHI3.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DgpEMrty.js", "/assets/shell-Dr4FHHI3.js"]
	},
	"/archive": {
		filePath: "/workspace/src/routes/archive.tsx",
		children: void 0,
		preloads: ["/assets/archive-efZNiBno.js", "/assets/shell-Dr4FHHI3.js"]
	},
	"/new": {
		filePath: "/workspace/src/routes/new.tsx",
		children: void 0,
		preloads: [
			"/assets/new-C-jg1XNx.js",
			"/assets/useNavigate-C-Y4rKNu.js",
			"/assets/shell-Dr4FHHI3.js"
		]
	},
	"/rules": {
		filePath: "/workspace/src/routes/rules.tsx",
		children: void 0,
		preloads: ["/assets/rules-Dm-zNRcj.js", "/assets/shell-Dr4FHHI3.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-g96lEbHr.js", "/assets/shell-Dr4FHHI3.js"]
	},
	"/log/$gameId": {
		filePath: "/workspace/src/routes/log.$gameId.tsx",
		children: void 0,
		preloads: ["/assets/log._gameId-B3Z41DIW.js", "/assets/shell-Dr4FHHI3.js"]
	},
	"/play/$gameId": {
		filePath: "/workspace/src/routes/play.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/play._gameId-oBeyFdNT.js",
			"/assets/useNavigate-C-Y4rKNu.js",
			"/assets/shell-Dr4FHHI3.js",
			"/assets/feedback-C9-KU-d4.js"
		]
	},
	"/round/$gameId": {
		filePath: "/workspace/src/routes/round.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/round._gameId-D_-JMfs_.js",
			"/assets/useNavigate-C-Y4rKNu.js",
			"/assets/shell-Dr4FHHI3.js",
			"/assets/feedback-C9-KU-d4.js"
		]
	},
	"/detail/$gameId/$roundId": {
		filePath: "/workspace/src/routes/detail.$gameId.$roundId.tsx",
		children: void 0,
		preloads: ["/assets/detail._gameId._roundId-BTVvX2YC.js", "/assets/shell-Dr4FHHI3.js"]
	}
} });
//#endregion
export { tsrStartManifest };
