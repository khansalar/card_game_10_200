package com.khansalar.dahdovist.domain

/**
 * Immutable round-list operations. Scores are never patched in place: callers re-run [derive]
 * on the returned list so every later cumulative total and qualification flag is rebuilt.
 * Android-free.
 */
enum class RejectReason {
    DuplicateId,
    DeclarationOutOfRange,
    ActualOutOfRange,
    TrickSumInvalid,
    TricksPerRoundInvalid,
    RoundNotFound,
}

/**
 * A round as it might come off disk. Stored totals and qualification flags are never read.
 * [sanitize] keeps the raw bids and drops corrupt rows; [derive] rebuilds every total.
 */
data class PersistedRound(
    val id: String,
    val declaredA: Int,
    val declaredB: Int,
    val actualA: Int,
    val actualB: Int,
    val storedScoreA: Int? = null,
    val storedScoreB: Int? = null,
    val storedQualifiedA: Boolean? = null,
    val storedQualifiedB: Boolean? = null,
)

sealed class AppendOutcome {
    data class Accepted(val rounds: List<RoundInput>) : AppendOutcome()

    data class Rejected(
        val reason: RejectReason,
        val rounds: List<RoundInput>,
    ) : AppendOutcome()
}

object GameReducer {
    fun validateRound(round: RoundInput, rules: Rules): RejectReason? {
        if (rules.tricksPerRound !in 1..26) return RejectReason.TricksPerRoundInvalid
        if (round.declaredA !in 0..10 || round.declaredB !in 0..10) {
            return RejectReason.DeclarationOutOfRange
        }
        if (round.actualA !in 0..rules.tricksPerRound || round.actualB !in 0..rules.tricksPerRound) {
            return RejectReason.ActualOutOfRange
        }
        val sum = round.actualA + round.actualB
        return when (rules.trickValidation) {
            TrickValidation.Off -> null
            TrickValidation.Exact ->
                if (sum == rules.tricksPerRound) null else RejectReason.TrickSumInvalid
            TrickValidation.AtMost ->
                if (sum <= rules.tricksPerRound) null else RejectReason.TrickSumInvalid
        }
    }

    /**
     * Append [round] or reject it. The input list is never mutated.
     * A duplicate id is rejected even when the payload is otherwise invalid.
     */
    fun appendRound(rounds: List<RoundInput>, round: RoundInput, rules: Rules): AppendOutcome {
        if (rounds.any { it.id == round.id }) {
            return AppendOutcome.Rejected(RejectReason.DuplicateId, rounds)
        }
        val problem = validateRound(round, rules)
        if (problem != null) return AppendOutcome.Rejected(problem, rounds)
        return AppendOutcome.Accepted(rounds + round)
    }

    /** Drop the last round. Returns a new list. An empty list stays empty. */
    fun undoLast(rounds: List<RoundInput>): List<RoundInput> {
        if (rounds.isEmpty()) return emptyList()
        return rounds.subList(0, rounds.lastIndex).toList()
    }

    /**
     * Replace the round with the same id. Does not touch any cumulative field.
     * The caller must [derive] the whole list again, including every later round.
     */
    fun replaceRound(rounds: List<RoundInput>, round: RoundInput, rules: Rules): AppendOutcome {
        val index = rounds.indexOfFirst { it.id == round.id }
        if (index < 0) return AppendOutcome.Rejected(RejectReason.RoundNotFound, rounds)
        val problem = validateRound(round, rules)
        if (problem != null) return AppendOutcome.Rejected(problem, rounds)
        val updated = ArrayList<RoundInput>(rounds.size)
        rounds.forEachIndexed { i, existing ->
            updated += if (i == index) round else existing
        }
        return AppendOutcome.Accepted(updated)
    }

    /**
     * Drop blank ids, duplicate ids (keep the first), and rounds that fail [validateRound].
     * Stored scores and stored qualification flags are ignored.
     * Declared and actual values of kept rounds are copied unchanged.
     */
    fun sanitize(saved: List<PersistedRound>, rules: Rules): List<RoundInput> {
        val seen = HashSet<String>()
        val kept = ArrayList<RoundInput>(saved.size)
        for (round in saved) {
            if (round.id.isBlank() || !seen.add(round.id)) continue
            val input = RoundInput(
                id = round.id,
                declaredA = round.declaredA,
                declaredB = round.declaredB,
                actualA = round.actualA,
                actualB = round.actualB,
            )
            if (validateRound(input, rules) != null) continue
            kept += input
        }
        return kept
    }
}
