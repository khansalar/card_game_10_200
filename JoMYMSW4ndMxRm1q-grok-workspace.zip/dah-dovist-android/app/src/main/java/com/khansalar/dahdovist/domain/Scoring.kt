package com.khansalar.dahdovist.domain

/**
 * Pure scoring for ده دویست. This file must stay free of Android imports so JVM unit tests can run it.
 *
 * Points: declaration 10 is ±200, never ±100. Any other declaration N is ±(N * 10).
 * Declaration 0 under [SuccessMode.AtLeast] always succeeds and is worth 0.
 * Qualification is per team and only happens when that team declares 8 and succeeds.
 * Warning is score > 400 and not qualified (400 itself does not warn).
 * A team can win only at score >= 500 and qualified. Otherwise a 500+ score is [TeamTally.blockedWin].
 * If both teams are eligible, the higher score wins. Equal eligible scores are a single [Winner.Draw].
 */
enum class SuccessMode {
    AtLeast,
    Exact,
}

enum class TrickValidation {
    Off,
    Exact,
    AtMost,
}

enum class Winner {
    None,
    A,
    B,
    Draw,
}

enum class GameStatus {
    Active,
    Completed,
}

data class Rules(
    val tricksPerRound: Int = 13,
    val trickValidation: TrickValidation = TrickValidation.Exact,
    val successMode: SuccessMode = SuccessMode.AtLeast,
)

data class RoundInput(
    val id: String,
    val declaredA: Int,
    val declaredB: Int,
    val actualA: Int,
    val actualB: Int,
)

data class TeamTally(
    val score: Int,
    val positive: Int,
    val negative: Int,
    val qualified: Boolean,
    val lastDeclared: Int?,
    val lastActual: Int?,
    val lastPoints: Int?,
    val lastSuccess: Boolean?,
    val warning: Boolean,
    val eligible: Boolean,
    val blockedWin: Boolean,
)

data class RoundLedger(
    val input: RoundInput,
    val pointsA: Int,
    val pointsB: Int,
    val successA: Boolean,
    val successB: Boolean,
    val scoreA: Int,
    val scoreB: Int,
    val positiveA: Int,
    val negativeA: Int,
    val positiveB: Int,
    val negativeB: Int,
    val qualifiedA: Boolean,
    val qualifiedB: Boolean,
)

data class DerivedMatch(
    val rounds: List<RoundLedger>,
    val teamA: TeamTally,
    val teamB: TeamTally,
    val winner: Winner,
    val status: GameStatus,
)

fun isSuccess(declared: Int, actual: Int, mode: SuccessMode): Boolean {
    if (declared == 0 && mode == SuccessMode.AtLeast) return true
    return when (mode) {
        SuccessMode.AtLeast -> actual >= declared
        SuccessMode.Exact -> actual == declared
    }
}

/**
 * Signed points for one declaration. Does not clamp or rewrite [declared] or [actual].
 * A bid of 10 is ±200. Every other bid N is ±(N * 10), including 0.
 */
fun score(declared: Int, actual: Int, mode: SuccessMode): Int {
    val success = isSuccess(declared, actual, mode)
    val magnitude = if (declared == 10) 200 else declared * 10
    return if (success) magnitude else -magnitude
}

/** True only when this team declared 8 and that declaration succeeded. */
fun qualifies(declared: Int, actual: Int, mode: SuccessMode): Boolean {
    return declared == 8 && isSuccess(declared, actual, mode)
}

fun isWarning(score: Int, qualified: Boolean): Boolean = score > 400 && !qualified

fun isEligible(score: Int, qualified: Boolean): Boolean = score >= 500 && qualified

fun isBlockedWin(score: Int, qualified: Boolean): Boolean = score >= 500 && !qualified

fun decideWinner(
    scoreA: Int,
    qualifiedA: Boolean,
    scoreB: Int,
    qualifiedB: Boolean,
): Winner {
    val aEligible = isEligible(scoreA, qualifiedA)
    val bEligible = isEligible(scoreB, qualifiedB)
    return when {
        aEligible && bEligible -> when {
            scoreA > scoreB -> Winner.A
            scoreB > scoreA -> Winner.B
            else -> Winner.Draw
        }
        aEligible -> Winner.A
        bEligible -> Winner.B
        else -> Winner.None
    }
}

fun statusFor(winner: Winner): GameStatus {
    return if (winner == Winner.None) GameStatus.Active else GameStatus.Completed
}

/**
 * Pure fold. Totals, qualification, warnings and the winner are derived only from round inputs.
 * Positive points and negative points are accumulated separately. Negatives are a negative sum.
 * The input list is not mutated.
 */
fun derive(rounds: List<RoundInput>, rules: Rules): DerivedMatch {
    var positiveA = 0
    var negativeA = 0
    var positiveB = 0
    var negativeB = 0
    var qualifiedA = false
    var qualifiedB = false
    var lastDeclaredA: Int? = null
    var lastActualA: Int? = null
    var lastPointsA: Int? = null
    var lastSuccessA: Boolean? = null
    var lastDeclaredB: Int? = null
    var lastActualB: Int? = null
    var lastPointsB: Int? = null
    var lastSuccessB: Boolean? = null
    val ledger = ArrayList<RoundLedger>(rounds.size)
    for (round in rounds) {
        val successA = isSuccess(round.declaredA, round.actualA, rules.successMode)
        val successB = isSuccess(round.declaredB, round.actualB, rules.successMode)
        val pointsA = score(round.declaredA, round.actualA, rules.successMode)
        val pointsB = score(round.declaredB, round.actualB, rules.successMode)
        if (pointsA > 0) positiveA += pointsA else if (pointsA < 0) negativeA += pointsA
        if (pointsB > 0) positiveB += pointsB else if (pointsB < 0) negativeB += pointsB
        if (qualifies(round.declaredA, round.actualA, rules.successMode)) qualifiedA = true
        if (qualifies(round.declaredB, round.actualB, rules.successMode)) qualifiedB = true
        lastDeclaredA = round.declaredA
        lastActualA = round.actualA
        lastPointsA = pointsA
        lastSuccessA = successA
        lastDeclaredB = round.declaredB
        lastActualB = round.actualB
        lastPointsB = pointsB
        lastSuccessB = successB
        ledger += RoundLedger(
            input = round,
            pointsA = pointsA,
            pointsB = pointsB,
            successA = successA,
            successB = successB,
            scoreA = positiveA + negativeA,
            scoreB = positiveB + negativeB,
            positiveA = positiveA,
            negativeA = negativeA,
            positiveB = positiveB,
            negativeB = negativeB,
            qualifiedA = qualifiedA,
            qualifiedB = qualifiedB,
        )
    }
    val scoreA = positiveA + negativeA
    val scoreB = positiveB + negativeB
    val winner = decideWinner(scoreA, qualifiedA, scoreB, qualifiedB)
    return DerivedMatch(
        rounds = ledger,
        teamA = tally(
            score = scoreA,
            positive = positiveA,
            negative = negativeA,
            qualified = qualifiedA,
            lastDeclared = lastDeclaredA,
            lastActual = lastActualA,
            lastPoints = lastPointsA,
            lastSuccess = lastSuccessA,
        ),
        teamB = tally(
            score = scoreB,
            positive = positiveB,
            negative = negativeB,
            qualified = qualifiedB,
            lastDeclared = lastDeclaredB,
            lastActual = lastActualB,
            lastPoints = lastPointsB,
            lastSuccess = lastSuccessB,
        ),
        winner = winner,
        status = statusFor(winner),
    )
}

private fun tally(
    score: Int,
    positive: Int,
    negative: Int,
    qualified: Boolean,
    lastDeclared: Int?,
    lastActual: Int?,
    lastPoints: Int?,
    lastSuccess: Boolean?,
): TeamTally {
    return TeamTally(
        score = score,
        positive = positive,
        negative = negative,
        qualified = qualified,
        lastDeclared = lastDeclared,
        lastActual = lastActual,
        lastPoints = lastPoints,
        lastSuccess = lastSuccess,
        warning = isWarning(score, qualified),
        eligible = isEligible(score, qualified),
        blockedWin = isBlockedWin(score, qualified),
    )
}
