package com.khansalar.dahdovist

import com.khansalar.dahdovist.domain.AppendOutcome
import com.khansalar.dahdovist.domain.GameReducer
import com.khansalar.dahdovist.domain.GameStatus
import com.khansalar.dahdovist.domain.PersistedRound
import com.khansalar.dahdovist.domain.RejectReason
import com.khansalar.dahdovist.domain.RoundInput
import com.khansalar.dahdovist.domain.Rules
import com.khansalar.dahdovist.domain.SuccessMode
import com.khansalar.dahdovist.domain.TrickValidation
import com.khansalar.dahdovist.domain.Winner
import com.khansalar.dahdovist.domain.derive
import com.khansalar.dahdovist.domain.isBlockedWin
import com.khansalar.dahdovist.domain.isEligible
import com.khansalar.dahdovist.domain.isSuccess
import com.khansalar.dahdovist.domain.isWarning
import com.khansalar.dahdovist.domain.qualifies
import com.khansalar.dahdovist.domain.score
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class ScoringTest {
    private val atLeast = SuccessMode.AtLeast
    private val exact = SuccessMode.Exact
    private val openRules = Rules(trickValidation = TrickValidation.Off)

    @Test
    fun declare4Actual4IsPlus40() {
        assertEquals(40, score(4, 4, atLeast))
        assertTrue(isSuccess(4, 4, atLeast))
    }

    @Test
    fun declare4Actual3IsMinus40() {
        assertEquals(-40, score(4, 3, atLeast))
        assertFalse(isSuccess(4, 3, atLeast))
        val derived = derive(listOf(round("1", 4, 4, 3, 5)), openRules)
        assertEquals(-40, derived.teamA.score)
        assertEquals(0, derived.teamA.positive)
        assertEquals(-40, derived.teamA.negative)
        assertEquals(40, derived.teamB.positive)
        assertEquals(0, derived.teamB.negative)
    }

    @Test
    fun declare8Actual8QualifiesFor80() {
        assertEquals(80, score(8, 8, atLeast))
        assertTrue(qualifies(8, 8, atLeast))
        val derived = derive(listOf(round("1", 8, 0, 8, 0)), openRules)
        assertEquals(80, derived.teamA.score)
        assertTrue(derived.teamA.qualified)
        assertFalse(derived.teamB.qualified)
    }

    @Test
    fun declare8Actual7IsMinus80AndDoesNotQualify() {
        assertEquals(-80, score(8, 7, atLeast))
        assertFalse(qualifies(8, 7, atLeast))
        val derived = derive(listOf(round("1", 8, 0, 7, 0)), openRules)
        assertEquals(-80, derived.teamA.score)
        assertFalse(derived.teamA.qualified)
        assertFalse(derived.teamA.warning)
    }

    @Test
    fun declare10Actual10IsPlus200Not100() {
        val points = score(10, 10, atLeast)
        assertEquals(200, points)
        assertTrue(points != 100)
        assertFalse(qualifies(10, 10, atLeast))
    }

    @Test
    fun declare10Actual9IsMinus200() {
        val points = score(10, 9, atLeast)
        assertEquals(-200, points)
        assertTrue(points != -100)
        assertFalse(qualifies(10, 9, atLeast))
    }

    @Test
    fun warningOnlyAbove400WhenUnqualified() {
        assertTrue(isWarning(401, qualified = false))
        assertFalse(isWarning(400, qualified = false))
        assertFalse(isWarning(401, qualified = true))
        assertFalse(isWarning(800, qualified = true))

        val at400 = derive(
            listOf(round("a", 10, 0, 10, 0), round("b", 10, 0, 10, 0)),
            openRules,
        )
        assertEquals(400, at400.teamA.score)
        assertFalse(at400.teamA.qualified)
        assertFalse(at400.teamA.warning)

        val at410 = derive(
            listOf(
                round("a", 10, 0, 10, 0),
                round("b", 10, 0, 10, 0),
                round("c", 1, 0, 1, 0),
            ),
            openRules,
        )
        assertEquals(410, at410.teamA.score)
        assertTrue(at410.teamA.warning)
        assertFalse(at410.teamA.blockedWin)
        assertEquals(Winner.None, at410.winner)
        assertEquals(GameStatus.Active, at410.status)
    }

    @Test
    fun fiveHundredUnqualifiedIsNotWinnerQualifiedIs() {
        assertFalse(isEligible(500, qualified = false))
        assertTrue(isBlockedWin(500, qualified = false))
        assertTrue(isEligible(500, qualified = true))
        assertFalse(isBlockedWin(500, qualified = true))
        assertFalse(isEligible(499, qualified = true))

        val unqualified = derive(
            List(10) { index -> round("u$index", 5, 0, 5, 0) },
            openRules,
        )
        assertEquals(500, unqualified.teamA.score)
        assertFalse(unqualified.teamA.qualified)
        assertTrue(unqualified.teamA.blockedWin)
        assertFalse(unqualified.teamA.eligible)
        assertEquals(Winner.None, unqualified.winner)
        assertEquals(GameStatus.Active, unqualified.status)

        val qualified = derive(
            listOf(
                round("a", 10, 0, 10, 0),
                round("b", 10, 0, 10, 0),
                round("c", 8, 0, 8, 0),
                round("d", 2, 0, 2, 0),
            ),
            openRules,
        )
        assertEquals(500, qualified.teamA.score)
        assertTrue(qualified.teamA.qualified)
        assertTrue(qualified.teamA.eligible)
        assertEquals(Winner.A, qualified.winner)
        assertEquals(GameStatus.Completed, qualified.status)
    }

    @Test
    fun qualificationOfADoesNotQualifyB() {
        val derived = derive(listOf(round("1", 8, 8, 8, 7)), openRules)
        assertTrue(derived.teamA.qualified)
        assertEquals(80, derived.teamA.score)
        assertFalse(derived.teamB.qualified)
        assertEquals(-80, derived.teamB.score)

        val tookEightWithoutDeclaring = derive(listOf(round("2", 4, 0, 8, 0)), openRules)
        assertEquals(40, tookEightWithoutDeclaring.teamA.score)
        assertFalse(tookEightWithoutDeclaring.teamA.qualified)
        assertEquals(4, tookEightWithoutDeclaring.rounds.single().input.declaredA)
        assertEquals(8, tookEightWithoutDeclaring.rounds.single().input.actualA)
    }

    @Test
    fun undoRestoresScoreAndQualification() {
        val qualifying = round("1", 8, 0, 8, 0)
        val later = round("2", 4, 0, 3, 0)
        val seed = listOf(qualifying)
        val withBoth = GameReducer.appendRound(seed, later, openRules) as AppendOutcome.Accepted
        assertEquals(1, seed.size)
        val beforeUndo = derive(withBoth.rounds, openRules)
        assertEquals(40, beforeUndo.teamA.score)
        assertEquals(80, beforeUndo.teamA.positive)
        assertEquals(-40, beforeUndo.teamA.negative)
        assertTrue(beforeUndo.teamA.qualified)

        val afterUndo = GameReducer.undoLast(withBoth.rounds)
        assertEquals(listOf("1"), afterUndo.map { it.id })
        assertEquals(2, withBoth.rounds.size)
        val restored = derive(afterUndo, openRules)
        assertEquals(80, restored.teamA.score)
        assertTrue(restored.teamA.qualified)
        assertEquals(80, restored.teamA.positive)
        assertEquals(0, restored.teamA.negative)

        val cleared = derive(GameReducer.undoLast(afterUndo), openRules)
        assertEquals(0, cleared.teamA.score)
        assertFalse(cleared.teamA.qualified)
        assertEquals(0, cleared.teamA.positive)
        assertEquals(0, cleared.teamA.negative)
        assertTrue(GameReducer.undoLast(emptyList()).isEmpty())
    }

    @Test
    fun sanitizeAndDeriveHealTamperedTotal() {
        val saved = listOf(
            PersistedRound(
                id = "1",
                declaredA = 4,
                declaredB = 0,
                actualA = 4,
                actualB = 0,
                storedScoreA = 999,
                storedScoreB = 50,
                storedQualifiedA = true,
                storedQualifiedB = true,
            ),
            PersistedRound(
                id = "bad-declaration",
                declaredA = 11,
                declaredB = 0,
                actualA = 0,
                actualB = 0,
                storedScoreA = 100,
            ),
            PersistedRound(
                id = "1",
                declaredA = 9,
                declaredB = 0,
                actualA = 9,
                actualB = 0,
                storedScoreA = 90,
            ),
            PersistedRound(
                id = "bad-actual",
                declaredA = 2,
                declaredB = 0,
                actualA = 99,
                actualB = 0,
            ),
            PersistedRound(
                id = " ",
                declaredA = 10,
                declaredB = 0,
                actualA = 10,
                actualB = 0,
            ),
        )
        val clean = GameReducer.sanitize(saved, openRules)
        assertEquals(listOf("1"), clean.map { it.id })
        assertEquals(4, clean.single().declaredA)
        assertEquals(4, clean.single().actualA)
        val healed = derive(clean, Rules())
        assertEquals(40, healed.teamA.score)
        assertEquals(0, healed.teamB.score)
        assertFalse(healed.teamA.qualified)
        assertFalse(healed.teamB.qualified)
        assertEquals(Winner.None, healed.winner)
    }

    @Test
    fun trickValidationExactAtMostAndOff() {
        val exactRules = Rules(tricksPerRound = 13, trickValidation = TrickValidation.Exact)
        assertNull(GameReducer.validateRound(round("ok", 6, 7, 6, 7), exactRules))
        assertEquals(
            RejectReason.TrickSumInvalid,
            GameReducer.validateRound(round("short", 4, 4, 4, 4), exactRules),
        )

        val atMost = Rules(tricksPerRound = 13, trickValidation = TrickValidation.AtMost)
        assertEquals(
            RejectReason.TrickSumInvalid,
            GameReducer.validateRound(round("over", 10, 4, 10, 4), atMost),
        )
        assertNull(GameReducer.validateRound(round("edge", 10, 3, 10, 3), atMost))

        val off = Rules(tricksPerRound = 13, trickValidation = TrickValidation.Off)
        assertNull(GameReducer.validateRound(round("free", 10, 4, 10, 4), off))
        assertEquals(
            RejectReason.ActualOutOfRange,
            GameReducer.validateRound(round("high", 1, 0, 14, 0), off),
        )
        assertEquals(
            RejectReason.DeclarationOutOfRange,
            GameReducer.validateRound(round("decl", 11, 0, 0, 0), off),
        )
        assertEquals(
            RejectReason.TricksPerRoundInvalid,
            GameReducer.validateRound(round("tricks", 1, 0, 1, 0), Rules(tricksPerRound = 0)),
        )

        val rejected = GameReducer.appendRound(
            emptyList(),
            round("nope", 4, 4, 4, 4),
            exactRules,
        ) as AppendOutcome.Rejected
        assertEquals(RejectReason.TrickSumInvalid, rejected.reason)
        assertTrue(rejected.rounds.isEmpty())
    }

    @Test
    fun duplicateRoundIdIsRejectedAndLengthStaysOne() {
        val original = listOf(round("same", 6, 7, 6, 7))
        val duplicate = GameReducer.appendRound(
            original,
            round("same", 2, 2, 2, 2),
            Rules(),
        ) as AppendOutcome.Rejected
        assertEquals(RejectReason.DuplicateId, duplicate.reason)
        assertEquals(1, original.size)
        assertEquals(1, duplicate.rounds.size)
        assertSame(original, duplicate.rounds)
        assertEquals(6, original.single().declaredA)

        val mutable = mutableListOf(round("a", 0, 0, 0, 0))
        val accepted = GameReducer.appendRound(
            mutable,
            round("b", 0, 0, 0, 0),
            openRules,
        ) as AppendOutcome.Accepted
        assertEquals(1, mutable.size)
        assertEquals(2, accepted.rounds.size)
        assertEquals("a", mutable.single().id)
    }

    @Test
    fun bothEligibleHigherScoreWinsAndEqualScoresDraw() {
        val higher = derive(
            listOf(
                round("1", 10, 10, 10, 10),
                round("2", 10, 10, 10, 10),
                round("3", 8, 8, 8, 8),
                round("4", 2, 5, 2, 5),
            ),
            openRules,
        )
        assertEquals(500, higher.teamA.score)
        assertEquals(530, higher.teamB.score)
        assertTrue(higher.teamA.qualified)
        assertTrue(higher.teamB.qualified)
        assertEquals(Winner.B, higher.winner)
        assertEquals(GameStatus.Completed, higher.status)

        val level = derive(
            listOf(
                round("1", 10, 10, 10, 10),
                round("2", 10, 10, 10, 10),
                round("3", 8, 8, 8, 8),
                round("4", 2, 2, 2, 2),
            ),
            openRules,
        )
        assertEquals(500, level.teamA.score)
        assertEquals(500, level.teamB.score)
        assertEquals(Winner.Draw, level.winner)
        assertEquals(GameStatus.Completed, level.status)

        val onlyBEligible = derive(
            listOf(
                round("1", 10, 10, 10, 10),
                round("2", 10, 10, 10, 10),
                round("3", 10, 8, 10, 8),
                round("4", 0, 2, 0, 2),
            ),
            openRules,
        )
        assertEquals(600, onlyBEligible.teamA.score)
        assertFalse(onlyBEligible.teamA.qualified)
        assertEquals(500, onlyBEligible.teamB.score)
        assertTrue(onlyBEligible.teamB.qualified)
        assertEquals(Winner.B, onlyBEligible.winner)
    }

    @Test
    fun overtrickIsPlus40UnderAtLeastAndMinus40UnderExact() {
        assertEquals(40, score(4, 5, atLeast))
        assertEquals(40, score(4, 6, atLeast))
        assertTrue(isSuccess(4, 6, atLeast))
        assertEquals(-40, score(4, 5, exact))
        assertEquals(-40, score(4, 6, exact))
        assertFalse(isSuccess(4, 6, exact))
        assertFalse(qualifies(4, 8, atLeast))
    }

    @Test
    fun declarationZeroUnderAtLeastAlwaysSucceedsWithZeroPoints() {
        assertTrue(isSuccess(0, 0, atLeast))
        assertTrue(isSuccess(0, 13, atLeast))
        assertEquals(0, score(0, 0, atLeast))
        assertEquals(0, score(0, 13, atLeast))
        assertFalse(qualifies(0, 0, atLeast))
        assertTrue(isSuccess(0, 0, exact))
        assertFalse(isSuccess(0, 1, exact))
        assertEquals(0, score(0, 1, exact))
    }

    @Test
    fun replaceRoundReDerivesSubsequentTotalsFromScratch() {
        val first = round("1", 4, 0, 4, 0)
        val second = round("2", 4, 0, 4, 0)
        val replaced = GameReducer.replaceRound(
            listOf(first, second),
            round("1", 4, 0, 3, 0),
            openRules,
        ) as AppendOutcome.Accepted
        assertEquals(2, listOf(first, second).size)
        val derived = derive(replaced.rounds, openRules)
        assertEquals(-40, derived.rounds[0].pointsA)
        assertEquals(-40, derived.rounds[0].scoreA)
        assertEquals(40, derived.rounds[1].pointsA)
        assertEquals(0, derived.rounds[1].scoreA)
        assertEquals(0, derived.teamA.score)
        assertEquals(40, derived.teamA.positive)
        assertEquals(-40, derived.teamA.negative)
        assertFalse(derived.teamA.qualified)
    }

    private fun round(
        id: String,
        declaredA: Int,
        declaredB: Int,
        actualA: Int,
        actualB: Int,
    ): RoundInput = RoundInput(id, declaredA, declaredB, actualA, actualB)
}
