import { useRouter } from "@tanstack/react-router";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cx, faDigits, faSigned } from "@/lib/dahdovist/format";

export function Page({
  title,
  eyebrow,
  back,
  children,
  footer,
}: {
  title?: string;
  eyebrow?: string;
  back?: boolean;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const router = useRouter();
  return (
    <div className="felt relative min-h-dvh">
      <SuitField />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col px-4 py-5">
        {(back || title) && (
          <header className="mb-4 flex items-center gap-3">
            {back && (
              <button
                type="button"
                onClick={() => router.history.back()}
                className="flex size-11 items-center justify-center rounded-full border border-line/50 text-fg"
                aria-label="بازگشت"
              >
                <span aria-hidden className="text-lg">
                  →
                </span>
              </button>
            )}
            <div className="min-w-0">
              {eyebrow && <p className="text-xs text-brass">{eyebrow}</p>}
              {title && <h1 className="truncate text-xl font-semibold text-fg">{title}</h1>}
            </div>
          </header>
        )}
        <div className="flex flex-1 flex-col">{children}</div>
        {footer && <div className="mt-4">{footer}</div>}
      </div>
    </div>
  );
}

function SuitField() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <span className="pip absolute -top-2 start-3 text-7xl text-fg/10">♠</span>
      <span className="pip absolute top-24 end-2 text-6xl text-heart/20">♥</span>
      <span className="pip absolute bottom-16 start-6 text-6xl text-heart/15">♦</span>
      <span className="pip absolute -bottom-3 end-4 text-7xl text-fg/10">♣</span>
    </div>
  );
}

type BtnVariant = "solid" | "line" | "quiet" | "danger" | "green";

export function btnClass(variant: BtnVariant = "solid", className?: string) {
  return cx(
    "inline-flex min-h-11 items-center justify-center rounded-xl px-4 text-center text-sm font-semibold transition-opacity disabled:opacity-40",
    variant === "solid" && "bg-card text-ink",
    variant === "line" && "border border-line/70 bg-transparent text-fg",
    variant === "quiet" && "bg-transparent text-muted",
    variant === "danger" && "border border-heart/40 bg-transparent text-heart",
    variant === "green" && "bg-chip text-card",
    className,
  );
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant };

export function Btn({ variant = "solid", className, type = "button", ...props }: BtnProps) {
  return <button type={type} className={btnClass(variant, className)} {...props} />;
}

export function Num({ value, signed = false }: { value: number; signed?: boolean }) {
  return (
    <bdi dir="ltr" className="tabular-nums">
      {signed ? faSigned(value) : faDigits(value)}
    </bdi>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <section className={cx("rounded-2xl bg-card px-4 py-3 text-ink shadow-sm", className)}>{children}</section>
  );
}

export function ConfirmDialog({
  open,
  title,
  body,
  confirmLabel,
  danger,
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-4 sm:items-center" role="presentation">
      <div role="dialog" aria-modal="true" aria-labelledby="confirm-title" className="w-full max-w-md rounded-2xl bg-card p-4 text-ink">
        <h2 id="confirm-title" className="text-base font-semibold">
          {title}
        </h2>
        <p className="mt-2 text-sm leading-6 text-ink/80">{body}</p>
        <div className="mt-4 flex gap-2">
          <Btn variant="quiet" className="flex-1 text-ink" onClick={onClose}>
            انصراف
          </Btn>
          <Btn variant={danger ? "danger" : "green"} className="flex-1" onClick={onConfirm}>
            {confirmLabel}
          </Btn>
        </div>
      </div>
    </div>
  );
}

export { faDigits };
