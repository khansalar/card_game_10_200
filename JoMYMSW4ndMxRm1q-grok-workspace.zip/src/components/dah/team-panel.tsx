import { WIN_SCORE, type RoundRecord } from "@/lib/dahdovist/engine";
import { faDigits } from "@/lib/dahdovist/format";
import type { TeamSide } from "@/lib/dahdovist/store";
import { Card, Num } from "./shell";

export function TeamPanel({
  side,
  team,
  score,
  positive,
  negative,
  qualified,
  qualifiedAt,
  warning,
  blocked,
  leading,
  last,
  points,
  success,
}: {
  side: "A" | "B";
  team: TeamSide;
  score: number;
  positive: number;
  negative: number;
  qualified: boolean;
  qualifiedAt: number | null;
  warning: boolean;
  blocked: boolean;
  leading: boolean;
  last?: RoundRecord;
  points: number;
  success: boolean;
}) {
  const pct = Math.max(0, Math.min(100, (score / WIN_SCORE) * 100));
  const players = [team.p1, team.p2].filter(Boolean).join(" · ");
  const red = side === "A";
  return (
    <Card className="relative overflow-hidden">
      <span className={`pip absolute top-2 end-3 text-2xl ${red ? "text-heart/70" : "text-ink/50"}`} aria-hidden>
        {red ? "♥" : "♠"}
      </span>
      <span className={`pip absolute bottom-2 start-3 text-xl ${red ? "text-heart/40" : "text-ink/30"}`} aria-hidden>
        {red ? "♦" : "♣"}
      </span>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="truncate text-base font-semibold">{team.name}</h2>
          <p className="truncate text-xs text-ink/60">{players || "بدون نام بازیکن"}</p>
        </div>
        {leading && (
          <span className="rounded-full bg-brass/20 px-2 py-1 text-xs font-medium text-brass">پیش</span>
        )}
      </div>
      <p className={`mt-2 text-4xl font-bold tracking-tight ${score < 0 ? "text-heart" : "text-ink"}`}>
        <Num value={score} />
      </p>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-ink/10" aria-hidden>
        <div className="h-full rounded-full bg-chip" style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-1 text-xs text-ink/60">
        تا ۵۰۰: <Num value={Math.max(0, WIN_SCORE - score)} /> امتیاز
        {score >= WIN_SCORE ? " · از حد گذشت" : ""}
      </p>
      <dl className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-lg bg-ok/10 px-2 py-1.5">
          <dt className="text-ink/60">امتیاز مثبت</dt>
          <dd className="font-semibold text-ok">
            <Num value={positive} signed />
          </dd>
        </div>
        <div className="rounded-lg bg-heart/10 px-2 py-1.5">
          <dt className="text-ink/60">امتیاز منفی</dt>
          <dd className="font-semibold text-heart">
            <Num value={negative} signed />
          </dd>
        </div>
      </dl>
      <p className="mt-3 text-xs">
        <span className={qualified ? "font-semibold text-ok" : "text-ink/70"}>
          {qualified
            ? `شرط ۸ انجام شد${qualifiedAt ? ` · دست ${faDigits(qualifiedAt)}` : ""}`
            : "شرط ۸ هنوز انجام نشده"}
        </span>
      </p>
      <div className="mt-2 rounded-lg border border-line/30 px-2 py-1.5 text-xs">
        {last ? (
          <p>
            آخرین دست: اعلام <Num value={side === "A" ? last.declaredA : last.declaredB} /> · گرفته{" "}
            <Num value={side === "A" ? last.actualA : last.actualB} /> ·{" "}
            <span className={success ? "text-ok" : "text-heart"}>{success ? "موفق" : "ناموفق"}</span>{" "}
            <Num value={points} signed />
          </p>
        ) : (
          <p className="text-ink/60">هنوز دستی ثبت نشده</p>
        )}
      </div>
      {warning && (
        <p className="mt-2 text-xs leading-5 text-heart">
          هشدار: این تیم هنوز شرط برد با اعلام و گرفتن ۸ دست را تکمیل نکرده است.
        </p>
      )}
      {blocked && (
        <p className="mt-1 text-xs leading-5 font-medium text-heart">
          امتیاز به ۵۰۰ رسیده، اما شرط ۸ کامل نشده و این تیم برنده نیست.
        </p>
      )}
    </Card>
  );
}
