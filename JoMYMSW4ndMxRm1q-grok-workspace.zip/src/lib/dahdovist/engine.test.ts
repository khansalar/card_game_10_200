import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  appendRound,
  blockedByQualification,
  DEFAULT_RULES,
  deriveGame,
  isEligible,
  needsWarning,
  replaceRound,
  resolveWinner,
  sanitizeRounds,
  scoreTeam,
  undoLast,
  validateRound,
  type RulesConfig,
  type StoredRound,
} from "./engine.ts";

const atLeast: RulesConfig = { ...DEFAULT_RULES, tricksPerRound: 13, trickValidation: "exact" };

function round(
  id: string,
  declaredA: number,
  actualA: number,
  declaredB: number,
  actualB: number,
): StoredRound {
  return { id, declaredA, actualA, declaredB, actualB };
}

describe("scoreTeam", () => {
  it("1. declaration 4 made exactly scores +40", () => {
    const s = scoreTeam(4, 4);
    assert.equal(s.points, 40);
    assert.equal(s.success, true);
  });

  it("2. declaration 4 with fewer tricks scores −40", () => {
    const s = scoreTeam(4, 3);
    assert.equal(s.points, -40);
    assert.equal(s.success, false);
    assert.equal(s.earnedQualification, false);
  });

  it("overtrick still succeeds under atLeast", () => {
    assert.equal(scoreTeam(4, 6, "atLeast").points, 40);
    assert.equal(scoreTeam(4, 6, "exact").points, -40);
  });

  it("3. declaration 8 made scores +80 and qualifies", () => {
    const s = scoreTeam(8, 8);
    assert.equal(s.points, 80);
    assert.equal(s.earnedQualification, true);
    assert.equal(scoreTeam(8, 9).earnedQualification, true);
  });

  it("4. declaration 8 missed scores −80 and does not qualify", () => {
    const s = scoreTeam(8, 7);
    assert.equal(s.points, -80);
    assert.equal(s.earnedQualification, false);
  });

  it("5. declaration 10 made scores +200, not +100", () => {
    const s = scoreTeam(10, 10);
    assert.equal(s.points, 200);
    assert.notEqual(s.points, 100);
    assert.equal(s.isSpecialTen, true);
  });

  it("6. declaration 10 missed scores −200, not −100", () => {
    const s = scoreTeam(10, 9);
    assert.equal(s.points, -200);
    assert.notEqual(s.points, -100);
  });

  it("declaration 0 always succeeds for a non-negative actual", () => {
    assert.equal(scoreTeam(0, 0).points, 0);
    assert.equal(scoreTeam(0, 0).success, true);
  });
});

describe("warnings and winners", () => {
  it("7. score above 400 without qualification warns", () => {
    assert.equal(needsWarning(401, false), true);
    assert.equal(needsWarning(500, false), true);
  });

  it("8. score of exactly 400 does not warn", () => {
    assert.equal(needsWarning(400, false), false);
    assert.equal(needsWarning(400, true), false);
  });

  it("qualified teams never see the qualification warning", () => {
    assert.equal(needsWarning(480, true), false);
  });

  it("9. 500 without qualification is not a winner", () => {
    assert.equal(isEligible(500, false), false);
    assert.equal(blockedByQualification(500, false), true);
    assert.equal(resolveWinner(500, false, 0, false), null);
    assert.equal(resolveWinner(1000, false, 200, false), null);
  });

  it("10. 500 with qualification is eligible", () => {
    assert.equal(isEligible(500, true), true);
    assert.equal(resolveWinner(500, true, 100, false), "A");
  });

  it("11. team A qualification does not qualify team B", () => {
    const derived = deriveGame([round("r1", 8, 8, 4, 5)], atLeast);
    assert.equal(derived.qualifiedA, true);
    assert.equal(derived.qualifiedB, false);
    assert.equal(derived.scoreA, 80);
    assert.equal(derived.scoreB, 40);
    assert.equal(derived.winner, null);
  });

  it("higher score wins when both cross 500 qualified", () => {
    assert.equal(resolveWinner(560, true, 500, true), "A");
    assert.equal(resolveWinner(500, true, 540, true), "B");
  });

  it("equal eligible scores are an explicit draw, not two winners", () => {
    assert.equal(resolveWinner(500, true, 500, true), "draw");
  });

  it("integrates a 400-point unqualified team, then a warning above 400", () => {
    const rounds: StoredRound[] = [];
    for (let i = 0; i < 10; i++) rounds.push(round(`p${i}`, 4, 4, 0, 9));
    const at400 = deriveGame(rounds, { ...atLeast, trickValidation: "off" });
    assert.equal(at400.scoreA, 400);
    assert.equal(at400.qualifiedA, false);
    assert.equal(at400.warningA, false);
    const over = deriveGame(
      [...rounds, round("over", 1, 1, 0, 0)],
      { ...atLeast, trickValidation: "off" },
    );
    assert.equal(over.scoreA, 410);
    assert.equal(over.warningA, true);
    assert.equal(over.winner, null);
  });

  it("five successful tens do not win without the 8-trick qualification", () => {
    const rounds = [0, 1, 2, 3, 4].map((i) => round(`t${i}`, 10, 10, 0, 3));
    const derived = deriveGame(rounds, { ...atLeast, trickValidation: "off", tricksPerRound: 13 });
    assert.equal(derived.scoreA, 1000);
    assert.equal(derived.qualifiedA, false);
    assert.equal(derived.blockedWinA, true);
    assert.equal(derived.winner, null);
    assert.equal(derived.status, "active");
  });

  it("a qualified team at 500 wins and the match completes", () => {
    const rounds = [
      round("a", 10, 10, 0, 3),
      round("b", 10, 10, 0, 3),
      round("c", 8, 8, 0, 5),
      round("d", 2, 2, 0, 11),
    ];
    const derived = deriveGame(rounds, { ...atLeast, trickValidation: "off" });
    assert.equal(derived.scoreA, 500);
    assert.equal(derived.qualifiedA, true);
    assert.equal(derived.qualifiedAAtRound, 3);
    assert.equal(derived.winner, "A");
    assert.equal(derived.status, "completed");
  });
});

describe("history edits", () => {
  it("12. undoing a round restores score and qualification", () => {
    const first = appendRound([], round("q", 8, 8, 1, 5), atLeast);
    assert.equal(first.ok, true);
    if (!first.ok) return;
    const second = appendRound(first.rounds, round("n", 4, 4, 2, 9), atLeast);
    assert.equal(second.ok, true);
    if (!second.ok) return;
    const before = deriveGame(second.rounds, atLeast);
    assert.equal(before.scoreA, 120);
    assert.equal(before.qualifiedA, true);
    const undone = undoLast(second.rounds);
    const after = deriveGame(undone, atLeast);
    assert.equal(after.scoreA, 80);
    assert.equal(after.qualifiedA, true);
    const cleared = deriveGame(undoLast(undone), atLeast);
    assert.equal(cleared.scoreA, 0);
    assert.equal(cleared.qualifiedA, false);
    assert.equal(cleared.rounds.length, 0);
  });

  it("replacing the qualifying round recalculates later totals", () => {
    const rounds = [round("q", 8, 8, 1, 5), round("n", 4, 4, 2, 9)];
    const edited = replaceRound(rounds, "q", { declaredA: 8, actualA: 3, declaredB: 1, actualB: 10 }, atLeast);
    assert.equal(edited.ok, true);
    if (!edited.ok) return;
    const derived = deriveGame(edited.rounds, atLeast);
    assert.equal(derived.scoreA, -40);
    assert.equal(derived.qualifiedA, false);
    assert.equal(derived.rounds[1]?.cumulativeA, -40);
    assert.equal(derived.rounds[0]?.pointsA, -80);
  });

  it("13. saving and restoring preserves state and heals tampered totals", () => {
    const rounds = [round("r", 8, 8, 4, 5)];
    const saved = JSON.parse(JSON.stringify({ rounds, scoreA: 999, qualifiedA: false })) as {
      rounds: unknown;
      scoreA: number;
    };
    const restored = sanitizeRounds(saved.rounds);
    const derived = deriveGame(restored, atLeast);
    assert.deepEqual(restored, rounds);
    assert.equal(derived.scoreA, 80);
    assert.equal(derived.qualifiedA, true);
    assert.notEqual(derived.scoreA, saved.scoreA);
  });

  it("drops corrupt and duplicate rows instead of crashing", () => {
    const clean = sanitizeRounds([
      round("ok", 4, 4, 4, 4),
      { id: "bad", declaredA: 11, actualA: 0, declaredB: 0, actualB: 0 },
      round("ok", 1, 1, 1, 1),
      null,
      "nope",
    ]);
    assert.equal(clean.length, 1);
    assert.equal(clean[0]?.id, "ok");
  });
});

describe("validation and idempotency", () => {
  it("14. rejects trick totals that break the configured rule", () => {
    const low = validateRound(round("x", 4, 4, 4, 4), atLeast);
    assert.ok(low.includes("sum-exact"));
    const ok = validateRound(round("y", 6, 6, 4, 7), atLeast);
    assert.deepEqual(ok, []);
    const over = validateRound(round("z", 4, 10, 4, 4), {
      ...atLeast,
      trickValidation: "atMost",
    });
    assert.ok(over.includes("sum-at-most"));
    const loose = validateRound(round("w", 4, 10, 4, 4), { ...atLeast, trickValidation: "off" });
    assert.deepEqual(loose, []);
    const range = validateRound(round("v", 4, 14, 4, 0), atLeast);
    assert.ok(range.includes("actual-range"));
    const declared = validateRound(round("u", 11, 0, 0, 13), atLeast);
    assert.ok(declared.includes("declared-range"));
  });

  it("15. a repeated submission cannot record the same round twice", () => {
    const first = appendRound([], round("same", 4, 6, 3, 7), atLeast);
    assert.equal(first.ok, true);
    if (!first.ok) return;
    const second = appendRound(first.rounds, round("same", 4, 6, 3, 7), atLeast);
    assert.equal(second.ok, false);
    if (second.ok) return;
    assert.ok(second.issues.includes("duplicate"));
    assert.equal(deriveGame(first.rounds, atLeast).rounds.length, 1);
  });
});
