/**
 * Pure scoring engine for ده دویست (Dah-Dovist).
 * No I/O. UI and storage call these functions and keep the results.
 *
 * Assumptions (also shown in the rules screen):
 * - A declaration succeeds when actual tricks are at least the declaration
 *   (`atLeast`, the default). `exact` is optional and requires an equal count.
 * - Declaration 10 scores ±200, never ±100.
 * - Qualification is a successful declaration of exactly 8 (same success rule).
 * - Warning starts strictly above 400 points and only if unqualified.
 * - A team at or above 500 wins only if it is already qualified.
 * - If both teams become eligible together, the higher score wins.
 *   Equal scores finish as an explicit draw — never two winners.
 */

export const MIN_DECLARATION = 0;
export const MAX_DECLARATION = 10;
export const SPECIAL_DECLARATION = 10;
export const SPECIAL_POINTS = 200;
export const QUALIFYING_DECLARATION = 8;
export const WIN_SCORE = 500;
export const WARNING_SCORE = 400;
export const DEFAULT_TRICKS_PER_ROUND = 13;
export const MIN_TRICKS_PER_ROUND = 1;
export const MAX_TRICKS_PER_ROUND = 26;

export type SuccessMode = "atLeast" | "exact";
export type TrickValidation = "off" | "exact" | "atMost";
export type TeamId = "A" | "B";
export type Winner = TeamId | "draw" | null;

export type ValidationIssue =
  | "declared-range"
  | "actual-range"
  | "sum-exact"
  | "sum-at-most"
  | "duplicate"
  | "missing"
  | "closed";

export interface RulesConfig {
  tricksPerRound: number;
  trickValidation: TrickValidation;
  successMode: SuccessMode;
}

export const DEFAULT_RULES: RulesConfig = {
  tricksPerRound: DEFAULT_TRICKS_PER_ROUND,
  trickValidation: "exact",
  successMode: "atLeast",
};

export interface StoredRound {
  id: string;
  declaredA: number;
  actualA: number;
  declaredB: number;
  actualB: number;
}

export interface TeamRoundScore {
  points: number;
  success: boolean;
  /** True only when this round itself earns the 8-trick qualification. */
  earnedQualification: boolean;
  isSpecialTen: boolean;
}

export interface RoundRecord {
  id: string;
  number: number;
  declaredA: number;
  actualA: number;
  declaredB: number;
  actualB: number;
  pointsA: number;
  pointsB: number;
  successA: boolean;
  successB: boolean;
  earnedQualificationA: boolean;
  earnedQualificationB: boolean;
  cumulativeA: number;
  cumulativeB: number;
  qualifiedA: boolean;
  qualifiedB: boolean;
  warningA: boolean;
  warningB: boolean;
  blockedWinA: boolean;
  blockedWinB: boolean;
}

export interface DerivedGame {
  rounds: RoundRecord[];
  scoreA: number;
  scoreB: number;
  positiveA: number;
  negativeA: number;
  positiveB: number;
  negativeB: number;
  qualifiedA: boolean;
  qualifiedB: boolean;
  qualifiedAAtRound: number | null;
  qualifiedBAtRound: number | null;
  warningA: boolean;
  warningB: boolean;
  blockedWinA: boolean;
  blockedWinB: boolean;
  winner: Winner;
  status: "active" | "completed";
}

export function defaultRules(partial?: Partial<RulesConfig>): RulesConfig {
  const tricks = partial?.tricksPerRound;
  const trickValidation = partial?.trickValidation;
  const successMode = partial?.successMode;
  return {
    tricksPerRound:
      typeof tricks === "number" &&
      Number.isInteger(tricks) &&
      tricks >= MIN_TRICKS_PER_ROUND &&
      tricks <= MAX_TRICKS_PER_ROUND
        ? tricks
        : DEFAULT_TRICKS_PER_ROUND,
    trickValidation:
      trickValidation === "off" || trickValidation === "exact" || trickValidation === "atMost"
        ? trickValidation
        : "exact",
    successMode: successMode === "exact" || successMode === "atLeast" ? successMode : "atLeast",
  };
}

export function isSuccessful(declared: number, actual: number, mode: SuccessMode): boolean {
  return mode === "exact" ? actual === declared : actual >= declared;
}

/** Points for one team. Does not validate ranges — callers validate first. */
export function scoreTeam(
  declared: number,
  actual: number,
  mode: SuccessMode = "atLeast",
): TeamRoundScore {
  const success = isSuccessful(declared, actual, mode);
  const isSpecialTen = declared === SPECIAL_DECLARATION;
  const magnitude = isSpecialTen ? SPECIAL_POINTS : declared * 10;
  const points = success ? magnitude : -magnitude;
  return {
    points,
    success,
    earnedQualification: declared === QUALIFYING_DECLARATION && success,
    isSpecialTen,
  };
}

export function needsWarning(score: number, qualified: boolean): boolean {
  return score > WARNING_SCORE && !qualified;
}

export function isEligible(score: number, qualified: boolean): boolean {
  return score >= WIN_SCORE && qualified;
}

export function blockedByQualification(score: number, qualified: boolean): boolean {
  return score >= WIN_SCORE && !qualified;
}

/**
 * Deterministic winner.
 * Higher score wins if both are eligible. Equal eligible scores are a draw.
 */
export function resolveWinner(
  scoreA: number,
  qualifiedA: boolean,
  scoreB: number,
  qualifiedB: boolean,
): Winner {
  const a = isEligible(scoreA, qualifiedA);
  const b = isEligible(scoreB, qualifiedB);
  if (a && !b) return "A";
  if (b && !a) return "B";
  if (a && b) {
    if (scoreA > scoreB) return "A";
    if (scoreB > scoreA) return "B";
    return "draw";
  }
  return null;
}

export function validateRound(
  input: StoredRound | Omit<StoredRound, "id">,
  rules: RulesConfig,
  existingIds: readonly string[] = [],
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const cfg = defaultRules(rules);
  const declared = [input.declaredA, input.declaredB];
  const actual = [input.actualA, input.actualB];

  if (declared.some((d) => !Number.isInteger(d) || d < MIN_DECLARATION || d > MAX_DECLARATION)) {
    issues.push("declared-range");
  }
  if (actual.some((a) => !Number.isInteger(a) || a < 0 || a > cfg.tricksPerRound)) {
    issues.push("actual-range");
  }
  if (!issues.includes("actual-range") && !issues.includes("declared-range")) {
    const sum = input.actualA + input.actualB;
    if (cfg.trickValidation === "exact" && sum !== cfg.tricksPerRound) issues.push("sum-exact");
    if (cfg.trickValidation === "atMost" && sum > cfg.tricksPerRound) issues.push("sum-at-most");
  }
  if ("id" in input && input.id && existingIds.includes(input.id)) issues.push("duplicate");
  return issues;
}

export function deriveGame(rounds: readonly StoredRound[], rules?: RulesConfig): DerivedGame {
  const mode = defaultRules(rules).successMode;
  let scoreA = 0;
  let scoreB = 0;
  let positiveA = 0;
  let negativeA = 0;
  let positiveB = 0;
  let negativeB = 0;
  let qualifiedA = false;
  let qualifiedB = false;
  let qualifiedAAtRound: number | null = null;
  let qualifiedBAtRound: number | null = null;
  const records: RoundRecord[] = [];

  rounds.forEach((round, index) => {
    const a = scoreTeam(round.declaredA, round.actualA, mode);
    const b = scoreTeam(round.declaredB, round.actualB, mode);
    scoreA += a.points;
    scoreB += b.points;
    if (a.points > 0) positiveA += a.points;
    if (a.points < 0) negativeA += a.points;
    if (b.points > 0) positiveB += b.points;
    if (b.points < 0) negativeB += b.points;
    const earnedA = a.earnedQualification && !qualifiedA;
    const earnedB = b.earnedQualification && !qualifiedB;
    if (earnedA) {
      qualifiedA = true;
      qualifiedAAtRound = index + 1;
    }
    if (earnedB) {
      qualifiedB = true;
      qualifiedBAtRound = index + 1;
    }
    records.push({
      id: round.id,
      number: index + 1,
      declaredA: round.declaredA,
      actualA: round.actualA,
      declaredB: round.declaredB,
      actualB: round.actualB,
      pointsA: a.points,
      pointsB: b.points,
      successA: a.success,
      successB: b.success,
      earnedQualificationA: earnedA,
      earnedQualificationB: earnedB,
      cumulativeA: scoreA,
      cumulativeB: scoreB,
      qualifiedA,
      qualifiedB,
      warningA: needsWarning(scoreA, qualifiedA),
      warningB: needsWarning(scoreB, qualifiedB),
      blockedWinA: blockedByQualification(scoreA, qualifiedA),
      blockedWinB: blockedByQualification(scoreB, qualifiedB),
    });
  });

  const winner = resolveWinner(scoreA, qualifiedA, scoreB, qualifiedB);
  const last = records[records.length - 1];
  return {
    rounds: records,
    scoreA,
    scoreB,
    positiveA,
    negativeA,
    positiveB,
    negativeB,
    qualifiedA,
    qualifiedB,
    qualifiedAAtRound,
    qualifiedBAtRound,
    warningA: last ? last.warningA : false,
    warningB: last ? last.warningB : false,
    blockedWinA: blockedByQualification(scoreA, qualifiedA),
    blockedWinB: blockedByQualification(scoreB, qualifiedB),
    winner,
    status: winner ? "completed" : "active",
  };
}

export function appendRound(
  rounds: readonly StoredRound[],
  next: StoredRound,
  rules: RulesConfig,
): { ok: true; rounds: StoredRound[] } | { ok: false; issues: ValidationIssue[] } {
  const issues = validateRound(next, rules, rounds.map((r) => r.id));
  if (issues.length) return { ok: false, issues };
  return { ok: true, rounds: [...rounds, next] };
}

export function undoLast(rounds: readonly StoredRound[]): StoredRound[] {
  return rounds.slice(0, -1);
}

export function replaceRound(
  rounds: readonly StoredRound[],
  roundId: string,
  next: Omit<StoredRound, "id">,
  rules: RulesConfig,
): { ok: true; rounds: StoredRound[] } | { ok: false; issues: ValidationIssue[] } {
  const index = rounds.findIndex((r) => r.id === roundId);
  if (index < 0) return { ok: false, issues: ["missing"] };
  const candidate: StoredRound = { id: roundId, ...next };
  const issues = validateRound(candidate, rules, []);
  if (issues.length) return { ok: false, issues };
  const copy = rounds.slice();
  copy[index] = candidate;
  return { ok: true, rounds: copy };
}

export function isStoredRound(value: unknown): value is StoredRound {
  if (!value || typeof value !== "object") return false;
  const r = value as StoredRound;
  return (
    typeof r.id === "string" &&
    r.id.length > 0 &&
    r.id.length < 80 &&
    Number.isInteger(r.declaredA) &&
    Number.isInteger(r.actualA) &&
    Number.isInteger(r.declaredB) &&
    Number.isInteger(r.actualB) &&
    r.declaredA >= 0 &&
    r.declaredA <= 10 &&
    r.declaredB >= 0 &&
    r.declaredB <= 10 &&
    r.actualA >= 0 &&
    r.actualA <= MAX_TRICKS_PER_ROUND &&
    r.actualB >= 0 &&
    r.actualB <= MAX_TRICKS_PER_ROUND
  );
}

/** Drop corrupt rounds. Keeps order. Re-derivation fixes totals. */
export function sanitizeRounds(value: unknown): StoredRound[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const out: StoredRound[] = [];
  for (const item of value) {
    if (!isStoredRound(item) || seen.has(item.id)) continue;
    seen.add(item.id);
    out.push({
      id: item.id,
      declaredA: item.declaredA,
      actualA: item.actualA,
      declaredB: item.declaredB,
      actualB: item.actualB,
    });
  }
  return out;
}
