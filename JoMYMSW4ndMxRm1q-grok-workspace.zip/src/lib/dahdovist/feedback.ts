let audio: AudioContext | null = null;

function context(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctor = window.AudioContext;
  if (!Ctor) return null;
  if (!audio) audio = new Ctor();
  return audio;
}

export function playTone(kind: "ok" | "bad" | "win", enabled: boolean) {
  if (!enabled) return;
  const ctx = context();
  if (!ctx) return;
  void ctx.resume().catch(() => undefined);
  const now = ctx.currentTime;
  const notes = kind === "win" ? [523, 659, 784] : kind === "ok" ? [660] : [220, 180];
  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.05, now + 0.02 + i * 0.08);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.18 + i * 0.08);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + i * 0.08);
    osc.stop(now + 0.22 + i * 0.08);
  });
}

export function buzz(enabled: boolean, pattern: number | number[] = 12) {
  if (!enabled || typeof navigator === "undefined" || !navigator.vibrate) return;
  try {
    navigator.vibrate(pattern);
  } catch {
    /* some browsers throw if vibration is blocked */
  }
}
