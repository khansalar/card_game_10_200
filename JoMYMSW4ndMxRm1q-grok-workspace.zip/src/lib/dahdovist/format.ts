import type { ValidationIssue, Winner } from "./engine";

const FA = "۰۱۲۳۴۵۶۷۸۹";

export function faDigits(value: number | string): string {
  return String(value).replace(/\d/g, (d) => FA[Number(d)] ?? d);
}

export function faSigned(n: number): string {
  if (n > 0) return `+${faDigits(n)}`;
  if (n < 0) return `−${faDigits(Math.abs(n))}`;
  return faDigits(0);
}

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export const ISSUE_TEXT: Record<ValidationIssue, string> = {
  "declared-range": "اعلام باید عددی از ۰ تا ۱۰ باشد.",
  "actual-range": "دست‌های گرفته‌شده خارج از محدودهٔ این دور است.",
  "sum-exact": "مجموع دست‌های دو تیم با تعداد دست‌های دور یکی نیست.",
  "sum-at-most": "مجموع دست‌های دو تیم از تعداد دست‌های دور بیشتر است.",
  duplicate: "این دست قبلاً ثبت شده است.",
  missing: "این دست در تاریخچه پیدا نشد.",
  closed: "این بازی تمام شده است. برای ثبت دست تازه، آخرین دست را واگرد کنید.",
};

export function issueText(issues: ValidationIssue[]): string {
  return issues.map((i) => ISSUE_TEXT[i]).join(" ");
}

export function faWhen(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat("fa-IR", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function winnerLabel(winner: Winner, nameA: string, nameB: string): string {
  if (winner === "A") return `${nameA} برنده شد`;
  if (winner === "B") return `${nameB} برنده شد`;
  if (winner === "draw") return "تساوی — هیچ‌کدام به‌تنهایی برنده نیستند";
  return "بازی ادامه دارد";
}

export function ruleLine(rules: {
  tricksPerRound: number;
  trickValidation: "off" | "exact" | "atMost";
  successMode: "atLeast" | "exact";
}): string {
  const sum =
    rules.trickValidation === "exact"
      ? `مجموع دست‌ها دقیقاً ${faDigits(rules.tricksPerRound)}`
      : rules.trickValidation === "atMost"
        ? `مجموع دست‌ها حداکثر ${faDigits(rules.tricksPerRound)}`
        : `بدون قید مجموع، هر تیم ۰ تا ${faDigits(rules.tricksPerRound)}`;
  const mode = rules.successMode === "exact" ? "موفقیت فقط با تعداد دقیق" : "موفقیت با حداقل اعلام";
  return `${sum} · ${mode}`;
}
