import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  appendRound,
  defaultRules,
  deriveGame,
  replaceRound,
  sanitizeRounds,
  undoLast,
  type RulesConfig,
  type StoredRound,
  type SuccessMode,
  type TrickValidation,
  type ValidationIssue,
} from "./engine";

export interface TeamSide {
  name: string;
  p1: string;
  p2: string;
}

export interface Game {
  id: string;
  createdAt: string;
  updatedAt: string;
  teamA: TeamSide;
  teamB: TeamSide;
  rounds: StoredRound[];
  rules: RulesConfig;
}

export interface Settings {
  tricksPerRound: number;
  trickValidation: TrickValidation;
  successMode: SuccessMode;
  sound: boolean;
  haptic: boolean;
  theme: "dark" | "light";
}

export const DEFAULT_SETTINGS: Settings = {
  tricksPerRound: 13,
  trickValidation: "exact",
  successMode: "atLeast",
  sound: true,
  haptic: true,
  theme: "dark",
};

interface PersistedShape {
  settings: Settings;
  games: Game[];
  activeGameId: string | null;
}

interface Store extends PersistedShape {
  hydrated: boolean;
  startGame: (input: { teamA: TeamSide; teamB: TeamSide }) => string;
  saveRound: (
    gameId: string,
    round: StoredRound,
  ) => { ok: true } | { ok: false; issues: ValidationIssue[] };
  editRound: (
    gameId: string,
    roundId: string,
    next: Omit<StoredRound, "id">,
  ) => { ok: true } | { ok: false; issues: ValidationIssue[] };
  undo: (gameId: string) => boolean;
  removeGame: (gameId: string) => void;
  updateSettings: (partial: Partial<Settings>) => void;
}

function clip(value: unknown, fallback: string): string {
  const text = typeof value === "string" ? value.trim() : "";
  return (text || fallback).slice(0, 40);
}

function cleanTeam(value: unknown, fallback: string): TeamSide {
  const t = (value ?? {}) as Partial<TeamSide>;
  return {
    name: clip(t.name, fallback),
    p1: typeof t.p1 === "string" ? t.p1.trim().slice(0, 40) : "",
    p2: typeof t.p2 === "string" ? t.p2.trim().slice(0, 40) : "",
  };
}

export function cleanSettings(value: unknown): Settings {
  const s = (value ?? {}) as Partial<Settings>;
  const rules = defaultRules({
    tricksPerRound: s.tricksPerRound,
    trickValidation: s.trickValidation,
    successMode: s.successMode,
  });
  return {
    ...rules,
    sound: s.sound !== false,
    haptic: s.haptic !== false,
    theme: s.theme === "light" ? "light" : "dark",
  };
}

function cleanGame(value: unknown): Game | null {
  if (!value || typeof value !== "object") return null;
  const g = value as Partial<Game>;
  if (typeof g.id !== "string" || !g.id) return null;
  return {
    id: g.id.slice(0, 80),
    createdAt: typeof g.createdAt === "string" ? g.createdAt : new Date(0).toISOString(),
    updatedAt: typeof g.updatedAt === "string" ? g.updatedAt : new Date(0).toISOString(),
    teamA: cleanTeam(g.teamA, "تیم الف"),
    teamB: cleanTeam(g.teamB, "تیم ب"),
    rounds: sanitizeRounds(g.rounds),
    rules: defaultRules(g.rules),
  };
}

export function uid(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `id-${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`;
}

function touch(game: Game, rounds: StoredRound[]): Game {
  return { ...game, rounds, updatedAt: new Date().toISOString() };
}

export function applyTheme(theme: "dark" | "light") {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
}

export const useGameStore = create<Store>()(
  persist(
    (set, get) => ({
      settings: DEFAULT_SETTINGS,
      games: [],
      activeGameId: null,
      hydrated: false,
      startGame: (input) => {
        const id = uid();
        const now = new Date().toISOString();
        const { settings } = get();
        const game: Game = {
          id,
          createdAt: now,
          updatedAt: now,
          teamA: cleanTeam(input.teamA, "تیم الف"),
          teamB: cleanTeam(input.teamB, "تیم ب"),
          rounds: [],
          rules: defaultRules(settings),
        };
        set({ games: [game, ...get().games], activeGameId: id });
        return id;
      },
      saveRound: (gameId, round) => {
        const game = get().games.find((g) => g.id === gameId);
        if (!game) return { ok: false, issues: ["missing"] };
        if (deriveGame(game.rounds, game.rules).status === "completed") {
          return { ok: false, issues: ["closed"] };
        }
        const result = appendRound(game.rounds, round, game.rules);
        if (!result.ok) return result;
        set({
          games: get().games.map((g) => (g.id === gameId ? touch(g, result.rounds) : g)),
          activeGameId: gameId,
        });
        return { ok: true };
      },
      editRound: (gameId, roundId, next) => {
        const game = get().games.find((g) => g.id === gameId);
        if (!game) return { ok: false, issues: ["missing"] };
        const result = replaceRound(game.rounds, roundId, next, game.rules);
        if (!result.ok) return result;
        set({
          games: get().games.map((g) => (g.id === gameId ? touch(g, result.rounds) : g)),
        });
        return { ok: true };
      },
      undo: (gameId) => {
        const game = get().games.find((g) => g.id === gameId);
        if (!game || game.rounds.length === 0) return false;
        const rounds = undoLast(game.rounds);
        set({
          games: get().games.map((g) => (g.id === gameId ? touch(g, rounds) : g)),
        });
        return true;
      },
      removeGame: (gameId) => {
        const games = get().games.filter((g) => g.id !== gameId);
        set({
          games,
          activeGameId: get().activeGameId === gameId ? null : get().activeGameId,
        });
      },
      updateSettings: (partial) => {
        const settings = cleanSettings({ ...get().settings, ...partial });
        set({ settings });
        applyTheme(settings.theme);
      },
    }),
    {
      name: "dah-dovist-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state): PersistedShape => ({
        settings: state.settings,
        games: state.games,
        activeGameId: state.activeGameId,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<PersistedShape>;
        const games = Array.isArray(p.games)
          ? p.games.map(cleanGame).filter((g): g is Game => g !== null)
          : [];
        const active =
          typeof p.activeGameId === "string" && games.some((g) => g.id === p.activeGameId)
            ? p.activeGameId
            : null;
        return {
          ...current,
          settings: cleanSettings(p.settings),
          games,
          activeGameId: active,
        };
      },
      onRehydrateStorage: () => () => {
        const theme = useGameStore.getState().settings.theme;
        applyTheme(theme);
        useGameStore.setState({ hydrated: true });
      },
    },
  ),
);

export function useGame(id: string | undefined): Game | undefined {
  return useGameStore((s) => s.games.find((g) => g.id === id));
}

export function latestUnfinished(games: readonly Game[]): Game | undefined {
  return [...games]
    .filter((g) => deriveGame(g.rounds, g.rules).status === "active")
    .sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1))[0];
}
