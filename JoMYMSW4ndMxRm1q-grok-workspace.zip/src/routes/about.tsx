import { createFileRoute } from "@tanstack/react-router";
import { Card, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/about")({ component: AboutPage });

function AboutPage() {
  return (
    <Page title="درباره" back>
      <Card>
        <p className="pip text-center text-3xl text-heart" aria-hidden>
          ♥ ♠
        </p>
        <h2 className="mt-2 text-center text-lg font-semibold">ده دویست</h2>
        <p className="mt-2 text-center text-sm leading-6 text-ink/80">
          برگه امتیاز آفلاین برای بازی دو تیم. حساب دست‌ها، شرط ۸ و حد ۵۰۰ روی همین دستگاه می‌ماند.
        </p>
      </Card>
      <p className="mt-6 text-center text-xs text-muted">khansalar@gmail.com</p>
    </Page>
  );
}
