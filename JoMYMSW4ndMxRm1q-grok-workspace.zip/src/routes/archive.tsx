import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { deriveGame } from "@/lib/dahdovist/engine";
import { faWhen, winnerLabel } from "@/lib/dahdovist/format";
import { useGameStore } from "@/lib/dahdovist/store";
import { btnClass, ConfirmDialog, Num, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/archive")({ component: ArchivePage });

function ArchivePage() {
  const games = useGameStore((s) => s.games);
  const hydrated = useGameStore((s) => s.hydrated);
  const removeGame = useGameStore((s) => s.removeGame);
  const [pending, setPending] = useState<string | null>(null);
  const ordered = [...games].sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));

  return (
    <Page title="تاریخچه بازی‌ها" back>
      {!hydrated && <p className="text-sm text-muted">در حال خواندن…</p>}
      {hydrated && ordered.length === 0 && (
        <p className="text-sm text-muted">بازی ذخیره‌شده‌ای نیست.</p>
      )}
      <ul className="flex flex-col gap-3">
        {ordered.map((game) => {
          const d = deriveGame(game.rounds, game.rules);
          return (
            <li key={game.id} className="rounded-2xl bg-card p-3 text-ink">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="text-sm font-semibold">
                    {game.teamA.name} مقابل {game.teamB.name}
                  </h2>
                  <p className="text-xs text-ink/60">{faWhen(game.updatedAt)}</p>
                </div>
                <span className="text-xs text-brass">{d.status === "completed" ? "تمام" : "ناتمام"}</span>
              </div>
              <p className="mt-2 text-lg font-bold">
                <Num value={d.scoreA} /> — <Num value={d.scoreB} />
              </p>
              <p className="text-xs">{winnerLabel(d.winner, game.teamA.name, game.teamB.name)}</p>
              <div className="mt-3 flex gap-2">
                <Link to="/play/$gameId" params={{ gameId: game.id }} className={btnClass("green", "flex-1")}>
                  {d.status === "active" ? "ادامه" : "مشاهده"}
                </Link>
                <Link to="/log/$gameId" params={{ gameId: game.id }} className={btnClass("line", "flex-1 text-ink")}>
                  دست‌ها
                </Link>
                <button type="button" className={btnClass("danger")} onClick={() => setPending(game.id)}>
                  حذف
                </button>
              </div>
            </li>
          );
        })}
      </ul>
      <ConfirmDialog
        open={pending !== null}
        title="حذف بازی؟"
        body="این بازی فقط از حافظهٔ همین دستگاه پاک می‌شود."
        confirmLabel="حذف"
        danger
        onClose={() => setPending(null)}
        onConfirm={() => {
          if (pending) removeGame(pending);
          setPending(null);
        }}
      />
    </Page>
  );
}
