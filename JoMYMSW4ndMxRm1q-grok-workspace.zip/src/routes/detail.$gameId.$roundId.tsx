import { createFileRoute, Link } from "@tanstack/react-router";
import { deriveGame } from "@/lib/dahdovist/engine";
import { useGame, useGameStore } from "@/lib/dahdovist/store";
import { btnClass, Card, Num, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/detail/$gameId/$roundId")({ component: DetailPage });

function DetailPage() {
  const { gameId, roundId } = Route.useParams();
  const game = useGame(gameId);
  const hydrated = useGameStore((s) => s.hydrated);
  if (!hydrated) return <Page title="جزئیات دست">در حال خواندن…</Page>;
  if (!game) return <Page title="بازی پیدا نشد" back><p>این بازی وجود ندارد.</p></Page>;
  const round = deriveGame(game.rounds, game.rules).rounds.find((r) => r.id === roundId);
  if (!round) return <Page title="دست پیدا نشد" back><p>این دست در تاریخچه نیست.</p></Page>;

  return (
    <Page title={`دست ${round.number}`} eyebrow="جزئیات" back>
      <Card>
        <TeamBlock
          name={game.teamA.name}
          declared={round.declaredA}
          actual={round.actualA}
          points={round.pointsA}
          success={round.successA}
          earned={round.earnedQualificationA}
          cumulative={round.cumulativeA}
          warning={round.warningA}
          blocked={round.blockedWinA}
        />
        <div className="my-3 h-px bg-ink/10" />
        <TeamBlock
          name={game.teamB.name}
          declared={round.declaredB}
          actual={round.actualB}
          points={round.pointsB}
          success={round.successB}
          earned={round.earnedQualificationB}
          cumulative={round.cumulativeB}
          warning={round.warningB}
          blocked={round.blockedWinB}
        />
      </Card>
      <p className="mt-3 text-xs leading-5 text-muted">
        امتیاز تجمعی بعد از این دست دوباره از اول تاریخچه ساخته می‌شود. ویرایش، دست‌های دیگر را عوض نمی‌کند؛ فقط جمع‌ها را از نو حساب می‌کند.
      </p>
      <Link
        to="/round/$gameId"
        params={{ gameId }}
        search={{ edit: roundId }}
        className={btnClass("solid", "mt-4 w-full")}
      >
        ویرایش این دست
      </Link>
    </Page>
  );
}

function TeamBlock({
  name,
  declared,
  actual,
  points,
  success,
  earned,
  cumulative,
  warning,
  blocked,
}: {
  name: string;
  declared: number;
  actual: number;
  points: number;
  success: boolean;
  earned: boolean;
  cumulative: number;
  warning: boolean;
  blocked: boolean;
}) {
  return (
    <div className="text-sm leading-6">
      <h2 className="font-semibold">{name}</h2>
      <p>
        اعلام <Num value={declared} /> · گرفته <Num value={actual} /> ·{" "}
        <span className={success ? "text-ok" : "text-heart"}>{success ? "موفق" : "ناموفق"}</span>{" "}
        <Num value={points} signed />
      </p>
      <p className="text-xs text-ink/70">
        جمع بعد از دست: <Num value={cumulative} />
      </p>
      {earned && <p className="text-xs text-ok">شرط اعلام و گرفتن ۸ در این دست کامل شد.</p>}
      {warning && (
        <p className="text-xs text-heart">هشدار: این تیم هنوز شرط برد با اعلام و گرفتن ۸ دست را تکمیل نکرده است.</p>
      )}
      {blocked && <p className="text-xs font-medium text-heart">به ۵۰۰ رسیده اما به‌خاطر شرط ۸ برنده نیست.</p>}
    </div>
  );
}
