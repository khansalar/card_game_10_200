import { createFileRoute, Link } from "@tanstack/react-router";
import { deriveGame } from "@/lib/dahdovist/engine";
import { faWhen, winnerLabel } from "@/lib/dahdovist/format";
import { latestUnfinished, useGameStore } from "@/lib/dahdovist/store";
import { btnClass, Num } from "@/components/dah/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useGameStore((s) => s.hydrated);
  const games = useGameStore((s) => s.games);
  const resume = hydrated ? latestUnfinished(games) : undefined;
  const recent = hydrated ? [...games].sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1)).slice(0, 3) : [];

  return (
    <div className="felt relative min-h-dvh">
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
        <span className="pip absolute -top-4 start-2 text-8xl text-fg/10">♠</span>
        <span className="pip absolute top-28 end-0 text-7xl text-heart/20">♥</span>
      </div>
      <main className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 py-8">
        <p className="text-xs tracking-widest text-brass">DAH-DOVIST</p>
        <h1 className="mt-1 text-4xl font-bold text-fg">ده دویست</h1>
        <p className="mt-2 max-w-xs text-sm leading-6 text-muted">
          برگه امتیاز دو تیم. اعلام هر دست، حساب ۱۰ برابر، و برد با ۵۰۰ به‌شرط گرفتن ۸.
        </p>
        <div className="mt-6 grid grid-cols-4 gap-2" aria-hidden>
          {[
            ["♠", false],
            ["♥", true],
            ["♦", true],
            ["♣", false],
          ].map(([suit, red]) => (
            <div
              key={String(suit)}
              className={`pip flex h-16 items-center justify-center rounded-xl bg-card text-3xl shadow-sm ${red ? "text-heart" : "text-ink"}`}
            >
              {suit}
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-col gap-2">
          <Link to="/new" className={btnClass("solid")}>
            شروع بازی جدید
          </Link>
          {resume && (
            <Link to="/play/$gameId" params={{ gameId: resume.id }} className={btnClass("line")}>
              ادامه بازی · {resume.teamA.name} و {resume.teamB.name}
            </Link>
          )}
        </div>
        <section className="mt-8">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-fg">تاریخچه بازی‌ها</h2>
            <Link to="/archive" className="text-xs text-brass">
              همه
            </Link>
          </div>
          {!hydrated && <p className="text-sm text-muted">در حال خواندن بازی‌های ذخیره‌شده…</p>}
          {hydrated && recent.length === 0 && (
            <p className="rounded-2xl border border-line/30 px-3 py-4 text-sm text-muted">
              هنوز بازی‌ای ذخیره نشده. اولین دست را شروع کنید.
            </p>
          )}
          <ul className="flex flex-col gap-2">
            {recent.map((game) => {
              const d = deriveGame(game.rounds, game.rules);
              return (
                <li key={game.id}>
                  <Link
                    to="/play/$gameId"
                    params={{ gameId: game.id }}
                    className="block rounded-2xl bg-surface px-3 py-3"
                  >
                    <span className="flex items-center justify-between gap-2 text-sm">
                      <span className="truncate font-medium">
                        {game.teamA.name} <span className="text-muted">مقابل</span> {game.teamB.name}
                      </span>
                      <span className="shrink-0 text-xs text-brass">
                        {d.status === "completed" ? "تمام" : "ناتمام"}
                      </span>
                    </span>
                    <span className="mt-1 flex items-center justify-between text-xs text-muted">
                      <span>
                        <Num value={d.scoreA} /> — <Num value={d.scoreB} />
                      </span>
                      <span>{faWhen(game.updatedAt)}</span>
                    </span>
                    <span className="mt-1 block text-xs text-fg/80">
                      {winnerLabel(d.winner, game.teamA.name, game.teamB.name)}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
        <nav className="mt-auto flex justify-center gap-4 pt-8 text-sm text-brass">
          <Link to="/rules">قوانین</Link>
          <Link to="/settings">تنظیمات</Link>
          <Link to="/about">درباره</Link>
        </nav>
      </main>
    </div>
  );
}
