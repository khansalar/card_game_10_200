import { createFileRoute, Link } from "@tanstack/react-router";
import { deriveGame } from "@/lib/dahdovist/engine";
import { useGame, useGameStore } from "@/lib/dahdovist/store";
import { btnClass, Num, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/log/$gameId")({ component: LogPage });

function LogPage() {
  const { gameId } = Route.useParams();
  const game = useGame(gameId);
  const hydrated = useGameStore((s) => s.hydrated);
  if (!hydrated) return <Page title="دست‌ها">در حال خواندن…</Page>;
  if (!game) return <Page title="بازی پیدا نشد" back><p className="text-sm">این بازی وجود ندارد.</p></Page>;
  const derived = deriveGame(game.rounds, game.rules);

  return (
    <Page title="تاریخچه دست‌ها" eyebrow={`${game.teamA.name} و ${game.teamB.name}`} back>
      {derived.rounds.length === 0 && <p className="text-sm text-muted">هنوز دستی ثبت نشده است.</p>}
      <ol className="flex flex-col gap-2">
        {derived.rounds.map((round) => (
          <li key={round.id}>
            <Link
              to="/detail/$gameId/$roundId"
              params={{ gameId, roundId: round.id }}
              className="block rounded-2xl bg-card px-3 py-3 text-ink"
            >
              <span className="flex items-center justify-between text-sm font-semibold">
                <span>دست <Num value={round.number} /></span>
                <span className="text-xs font-normal text-ink/60">
                  <Num value={round.cumulativeA} /> — <Num value={round.cumulativeB} />
                </span>
              </span>
              <span className="mt-1 block text-xs leading-5 text-ink/80">
                {game.teamA.name}: اعلام <Num value={round.declaredA} />، گرفته <Num value={round.actualA} />،{" "}
                <Num value={round.pointsA} signed />
                <br />
                {game.teamB.name}: اعلام <Num value={round.declaredB} />، گرفته <Num value={round.actualB} />،{" "}
                <Num value={round.pointsB} signed />
              </span>
              {(round.earnedQualificationA || round.earnedQualificationB) && (
                <span className="mt-1 block text-xs text-ok">شرط ۸ در این دست کامل شد</span>
              )}
              {(round.warningA || round.warningB) && (
                <span className="mt-1 block text-xs text-heart">هشدار شرط ۸ برای تیم بالای ۴۰۰</span>
              )}
            </Link>
          </li>
        ))}
      </ol>
      <Link to="/play/$gameId" params={{ gameId }} className={btnClass("line", "mt-4")}>
        بازگشت به میز
      </Link>
    </Page>
  );
}
