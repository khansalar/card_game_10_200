import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { deriveGame } from "@/lib/dahdovist/engine";
import { ruleLine } from "@/lib/dahdovist/format";
import { useGameStore } from "@/lib/dahdovist/store";
import { Btn, Card, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/new")({ component: NewGame });

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block text-xs">
      <span className="mb-1 block text-ink/70">{label}</span>
      <input
        value={value}
        maxLength={40}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full rounded-xl border border-line/40 bg-card px-3 text-sm text-ink outline-none focus:border-brass"
      />
    </label>
  );
}

function NewGame() {
  const navigate = useNavigate();
  const settings = useGameStore((s) => s.settings);
  const games = useGameStore((s) => s.games);
  const startGame = useGameStore((s) => s.startGame);
  const unfinished = games.filter((g) => deriveGame(g.rounds, g.rules).status === "active").length;
  const [ack, setAck] = useState(false);
  const [teamA, setTeamA] = useState("تیم الف");
  const [a1, setA1] = useState("");
  const [a2, setA2] = useState("");
  const [teamB, setTeamB] = useState("تیم ب");
  const [b1, setB1] = useState("");
  const [b2, setB2] = useState("");

  const locked = unfinished > 0 && !ack;

  return (
    <Page title="بازی جدید" eyebrow="ده دویست" back>
      <Card className="flex flex-col gap-3">
        <h2 className="text-sm font-semibold">تیم الف</h2>
        <Field label="نام تیم" value={teamA} onChange={setTeamA} />
        <div className="grid grid-cols-2 gap-2">
          <Field label="بازیکن ۱" value={a1} onChange={setA1} placeholder="اختیاری" />
          <Field label="بازیکن ۲" value={a2} onChange={setA2} placeholder="اختیاری" />
        </div>
      </Card>
      <Card className="mt-3 flex flex-col gap-3">
        <h2 className="text-sm font-semibold">تیم ب</h2>
        <Field label="نام تیم" value={teamB} onChange={setTeamB} />
        <div className="grid grid-cols-2 gap-2">
          <Field label="بازیکن ۱" value={b1} onChange={setB1} placeholder="اختیاری" />
          <Field label="بازیکن ۲" value={b2} onChange={setB2} placeholder="اختیاری" />
        </div>
      </Card>
      <Card className="mt-3 text-sm leading-6">
        <h2 className="font-semibold">قانون این بازی</h2>
        <p className="mt-1 text-xs text-ink/70">{ruleLine(settings)}</p>
        <ul className="mt-2 list-disc pe-4 text-xs leading-5 text-ink/80">
          <li>موفقیت معمولی: اعلام ضربدر ۱۰. شکست: همان مقدار منفی.</li>
          <li>اعلام ۱۰: موفقیت ۲۰۰+ و شکست ۲۰۰−، نه ۱۰۰.</li>
          <li>برد از ۵۰۰، فقط بعد از یک اعلام موفقِ دقیقاً ۸.</li>
        </ul>
      </Card>
      {unfinished > 0 && (
        <label className="mt-3 flex items-start gap-2 rounded-2xl border border-brass/50 px-3 py-3 text-sm text-fg">
          <input
            type="checkbox"
            className="mt-1 size-4"
            checked={ack}
            onChange={(e) => setAck(e.target.checked)}
          />
          <span>بازی ناتمام قبلی پاک نمی‌شود و در تاریخچه می‌ماند. بازی جدید جدا ساخته می‌شود.</span>
        </label>
      )}
      <div className="mt-4">
        <Btn
          className="w-full"
          disabled={locked}
          onClick={() => {
            const id = startGame({
              teamA: { name: teamA, p1: a1, p2: a2 },
              teamB: { name: teamB, p1: b1, p2: b2 },
            });
            void navigate({ to: "/play/$gameId", params: { gameId: id } });
          }}
        >
          شروع امتیازدهی
        </Btn>
      </div>
    </Page>
  );
}
