import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { deriveGame } from "@/lib/dahdovist/engine";
import { ruleLine, winnerLabel } from "@/lib/dahdovist/format";
import { buzz, playTone } from "@/lib/dahdovist/feedback";
import { useGame, useGameStore } from "@/lib/dahdovist/store";
import { Btn, btnClass, ConfirmDialog, Page } from "@/components/dah/shell";
import { TeamPanel } from "@/components/dah/team-panel";

export const Route = createFileRoute("/play/$gameId")({ component: PlayPage });

function PlayPage() {
  const { gameId } = Route.useParams();
  const navigate = useNavigate();
  const game = useGame(gameId);
  const hydrated = useGameStore((s) => s.hydrated);
  const settings = useGameStore((s) => s.settings);
  const undo = useGameStore((s) => s.undo);
  const removeGame = useGameStore((s) => s.removeGame);
  const [askUndo, setAskUndo] = useState(false);
  const [askDelete, setAskDelete] = useState(false);
  const derived = useMemo(() => (game ? deriveGame(game.rounds, game.rules) : null), [game]);

  if (!hydrated) return <Page title="میز بازی">در حال خواندن…</Page>;
  if (!game || !derived) {
    return (
      <Page title="بازی پیدا نشد" back>
        <Link to="/" className={btnClass("solid")}>
          خانه
        </Link>
      </Page>
    );
  }

  const last = derived.rounds[derived.rounds.length - 1];
  const lead = derived.scoreA === derived.scoreB ? null : derived.scoreA > derived.scoreB ? "A" : "B";

  return (
    <Page title="میز بازی" eyebrow={ruleLine(game.rules)} back>
      {derived.winner && (
        <div className="mb-3 rounded-2xl border border-brass bg-surface px-3 py-3 text-sm">
          <p className="font-semibold text-brass">{winnerLabel(derived.winner, game.teamA.name, game.teamB.name)}</p>
          {derived.winner === "draw" && (
            <p className="mt-1 text-xs leading-5 text-muted">
              هر دو تیم همزمان به ۵۰۰ با شرط ۸ رسیدند و امتیازشان برابر است. نتیجه تساوی است، نه دو برنده.
            </p>
          )}
        </div>
      )}
      {(derived.blockedWinA || derived.blockedWinB) && (
        <div className="mb-3 rounded-2xl border border-heart/50 bg-surface px-3 py-3 text-xs leading-5 text-fg">
          حد ۵۰۰ رد شده اما اعلام موفق ۸ هنوز کامل نیست. تا آن وقت برنده‌ای اعلام نمی‌شود.
        </div>
      )}
      <div className="flex flex-col gap-3">
        <TeamPanel
          side="A"
          team={game.teamA}
          score={derived.scoreA}
          positive={derived.positiveA}
          negative={derived.negativeA}
          qualified={derived.qualifiedA}
          qualifiedAt={derived.qualifiedAAtRound}
          warning={derived.warningA}
          blocked={derived.blockedWinA}
          leading={lead === "A"}
          last={last}
          points={last?.pointsA ?? 0}
          success={last?.successA ?? false}
        />
        <TeamPanel
          side="B"
          team={game.teamB}
          score={derived.scoreB}
          positive={derived.positiveB}
          negative={derived.negativeB}
          qualified={derived.qualifiedB}
          qualifiedAt={derived.qualifiedBAtRound}
          warning={derived.warningB}
          blocked={derived.blockedWinB}
          leading={lead === "B"}
          last={last}
          points={last?.pointsB ?? 0}
          success={last?.successB ?? false}
        />
      </div>
      {lead === null && derived.rounds.length > 0 && !derived.winner && (
        <p className="mt-3 text-center text-xs text-brass">امتیاز دو تیم مساوی است</p>
      )}
      <div className="mt-4 grid grid-cols-2 gap-2">
        {derived.status === "active" ? (
          <Link to="/round/$gameId" params={{ gameId }} search={{ edit: undefined }} className={btnClass("solid", "col-span-2")}>
            ثبت نتیجه دست
          </Link>
        ) : (
          <p className="col-span-2 text-center text-xs text-muted">بازی بسته است. با واگرد می‌توانید آن را دوباره باز کنید.</p>
        )}
        <Btn variant="line" disabled={!game.rounds.length} onClick={() => setAskUndo(true)}>
          واگرد آخرین دست
        </Btn>
        <Link to="/log/$gameId" params={{ gameId }} className={btnClass("line")}>
          تاریخچه دست‌ها
        </Link>
        <Btn variant="danger" className="col-span-2" onClick={() => setAskDelete(true)}>
          حذف این بازی
        </Btn>
      </div>
      <ConfirmDialog
        open={askUndo}
        title="واگرد آخرین دست؟"
        body="آخرین دست حذف می‌شود و امتیاز هر دو تیم و شرط ۸ از روی دست‌های باقی‌مانده دوباره حساب می‌شود."
        confirmLabel="واگرد"
        onClose={() => setAskUndo(false)}
        onConfirm={() => {
          undo(gameId);
          playTone("bad", settings.sound);
          buzz(settings.haptic);
          setAskUndo(false);
        }}
      />
      <ConfirmDialog
        open={askDelete}
        title="حذف بازی؟"
        body="این بازی و همه دست‌هایش از همین دستگاه پاک می‌شود. این کار برگشت ندارد."
        confirmLabel="حذف"
        danger
        onClose={() => setAskDelete(false)}
        onConfirm={() => {
          removeGame(gameId);
          void navigate({ to: "/" });
        }}
      />
    </Page>
  );
}
