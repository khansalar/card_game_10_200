import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  deriveGame,
  scoreTeam,
  validateRound,
  WIN_SCORE,
  type StoredRound,
  type SuccessMode,
} from "@/lib/dahdovist/engine";
import { cx, faDigits, issueText, winnerLabel } from "@/lib/dahdovist/format";
import { buzz, playTone } from "@/lib/dahdovist/feedback";
import { useGame, useGameStore } from "@/lib/dahdovist/store";
import { Btn, Card, Num, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/round/$gameId")({
  validateSearch: (search: Record<string, unknown>) => ({
    edit: typeof search.edit === "string" ? search.edit : undefined,
  }),
  component: RoundPage,
});

function RoundPage() {
  const { gameId } = Route.useParams();
  const { edit } = Route.useSearch();
  const navigate = useNavigate();
  const game = useGame(gameId);
  const hydrated = useGameStore((s) => s.hydrated);
  const settings = useGameStore((s) => s.settings);
  const saveRound = useGameStore((s) => s.saveRound);
  const editRound = useGameStore((s) => s.editRound);
  const [declaredA, setDeclaredA] = useState<number | null>(null);
  const [actualA, setActualA] = useState<number | null>(null);
  const [declaredB, setDeclaredB] = useState<number | null>(null);
  const [actualB, setActualB] = useState<number | null>(null);
  const [phase, setPhase] = useState<"edit" | "confirm">("edit");
  const [roundId, setRoundId] = useState<string | null>(edit ?? null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [seeded, setSeeded] = useState(false);
  const lock = useRef(false);

  useEffect(() => {
    if (!game || seeded) return;
    if (edit) {
      const found = game.rounds.find((r) => r.id === edit);
      if (found) {
        setDeclaredA(found.declaredA);
        setActualA(found.actualA);
        setDeclaredB(found.declaredB);
        setActualB(found.actualB);
        setRoundId(found.id);
      }
    }
    setSeeded(true);
  }, [game, edit, seeded]);

  const ready = declaredA !== null && actualA !== null && declaredB !== null && actualB !== null;
  const draft: StoredRound | null = ready
    ? {
        id: roundId ?? "preview",
        declaredA,
        actualA,
        declaredB,
        actualB,
      }
    : null;

  const issues = draft && game ? validateRound(draft, game.rules, edit ? [] : []) : [];
  const editIndex = game && edit ? game.rounds.findIndex((r) => r.id === edit) : -1;
  const notLast = editIndex >= 0 && game ? editIndex < game.rounds.length - 1 : false;

  const preview = useMemo(() => {
    if (!game || !draft || issues.length) return null;
    const rounds = edit
      ? game.rounds.map((r) => (r.id === edit ? { ...draft, id: edit } : r))
      : [...game.rounds, draft];
    return deriveGame(rounds, game.rules);
  }, [game, draft, edit, issues.length]);

  if (!hydrated) return <Page title="ثبت دست">در حال خواندن…</Page>;
  if (!game) return <Page title="بازی پیدا نشد" back><p className="text-sm text-muted">این بازی وجود ندارد.</p></Page>;

  const closed = !edit && deriveGame(game.rounds, game.rules).status === "completed";
  const number = editIndex >= 0 ? editIndex + 1 : game.rounds.length + 1;
  const scoreA = draft ? scoreTeam(draft.declaredA, draft.actualA, game.rules.successMode) : null;
  const scoreB = draft ? scoreTeam(draft.declaredB, draft.actualB, game.rules.successMode) : null;

  function submit() {
    if (!draft || !game || lock.current) return;
    lock.current = true;
    setBusy(true);
    const payload = {
      declaredA: draft.declaredA,
      actualA: draft.actualA,
      declaredB: draft.declaredB,
      actualB: draft.actualB,
    };
    const id = roundId ?? crypto.randomUUID();
    const result = edit ? editRound(game.id, edit, payload) : saveRound(game.id, { id, ...payload });
    if (!result.ok) {
      lock.current = false;
      setBusy(false);
      setError(issueText(result.issues));
      return;
    }
    const done = deriveGame(
      useGameStore.getState().games.find((g) => g.id === game.id)?.rounds ?? [],
      game.rules,
    );
    playTone(done.winner ? "win" : "ok", settings.sound);
    buzz(settings.haptic, done.winner ? [20, 40, 20] : 12);
    void navigate({ to: "/play/$gameId", params: { gameId: game.id } });
  }

  return (
    <Page
      title={edit ? `ویرایش دست ${faDigits(number)}` : `دست ${faDigits(number)}`}
      eyebrow={game.teamA.name + " · " + game.teamB.name}
      back
      footer={
        phase === "edit" ? (
          <Btn
            className="w-full"
            disabled={!ready || issues.length > 0 || closed}
            onClick={() => {
              if (!edit) setRoundId(crypto.randomUUID());
              setError("");
              setPhase("confirm");
            }}
          >
            پیش‌نمایش و تأیید
          </Btn>
        ) : (
          <div className="flex gap-2">
            <Btn variant="line" className="flex-1" onClick={() => setPhase("edit")}>
              اصلاح
            </Btn>
            <Btn className="flex-1" disabled={busy} onClick={submit}>
              {busy ? "در حال ثبت…" : "ثبت نهایی"}
            </Btn>
          </div>
        )
      }
    >
      {closed && (
        <p className="mb-3 text-sm text-heart">این بازی تمام شده. تا واگرد آخرین دست، دست تازه ثبت نمی‌شود.</p>
      )}
      {phase === "edit" ? (
        <div className="flex flex-col gap-3">
          <TeamEntry
            name={game.teamA.name}
            suit="♥"
            declared={declaredA}
            actual={actualA}
            maxActual={game.rules.tricksPerRound}
            mode={game.rules.successMode}
            onDeclared={setDeclaredA}
            onActual={setActualA}
          />
          <TeamEntry
            name={game.teamB.name}
            suit="♠"
            declared={declaredB}
            actual={actualB}
            maxActual={game.rules.tricksPerRound}
            mode={game.rules.successMode}
            onDeclared={setDeclaredB}
            onActual={setActualB}
          />
          {issues.length > 0 && <p className="text-sm text-heart">{issueText(issues)}</p>}
          {notLast && (
            <p className="text-xs leading-5 text-brass">
              این دست آخرین دست نیست. بعد از ذخیره، امتیاز همه دست‌های بعدی و شرط ۸ دوباره حساب می‌شود. اعداد اعلام و گرفته‌شدهٔ دست‌های دیگر دست نمی‌خورد.
            </p>
          )}
        </div>
      ) : (
        draft &&
        scoreA &&
        scoreB && (
          <div className="flex flex-col gap-3">
            <Card>
              <h2 className="text-sm font-semibold">خلاصه قبل از ثبت</h2>
              <SummaryRow name={game.teamA.name} declared={draft.declaredA} actual={draft.actualA} points={scoreA.points} success={scoreA.success} qual={scoreA.earnedQualification && !deriveGame(edit ? game.rounds.slice(0, editIndex) : game.rounds, game.rules).qualifiedA} />
              <SummaryRow name={game.teamB.name} declared={draft.declaredB} actual={draft.actualB} points={scoreB.points} success={scoreB.success} qual={scoreB.earnedQualification && !deriveGame(edit ? game.rounds.slice(0, editIndex) : game.rounds, game.rules).qualifiedB} />
            </Card>
            {preview && (
              <Card>
                <p className="text-sm">
                  امتیاز بعد از این دست: {game.teamA.name} <Num value={preview.scoreA} /> · {game.teamB.name}{" "}
                  <Num value={preview.scoreB} />
                </p>
                <p className="mt-1 text-xs text-ink/70">حد برد: <Num value={WIN_SCORE} /></p>
                {(preview.warningA || preview.warningB || preview.blockedWinA || preview.blockedWinB) && (
                  <p className="mt-2 text-xs leading-5 text-heart">
                    هشدار: تیمی که بالای ۴۰۰ است و هنوز اعلام موفق ۸ ندارد، برنده حساب نمی‌شود.
                    {(preview.blockedWinA || preview.blockedWinB) && " حد ۵۰۰ رد شده اما شرط ۸ مانده است."}
                  </p>
                )}
                {preview.winner && (
                  <p className="mt-2 text-sm font-semibold text-ok">
                    با این ثبت، بازی تمام می‌شود. {winnerLabel(preview.winner, game.teamA.name, game.teamB.name)}
                  </p>
                )}
              </Card>
            )}
            {(draft.declaredA === 10 || draft.declaredB === 10) && (
              <p className="text-xs text-brass">قانون ۱۰: به‌جای ۱۰۰، نتیجه ۲۰۰+ یا ۲۰۰− است.</p>
            )}
            {error && <p className="text-sm text-heart">{error}</p>}
          </div>
        )
      )}
    </Page>
  );
}

function TeamEntry({
  name,
  suit,
  declared,
  actual,
  maxActual,
  mode,
  onDeclared,
  onActual,
}: {
  name: string;
  suit: string;
  declared: number | null;
  actual: number | null;
  maxActual: number;
  mode: SuccessMode;
  onDeclared: (n: number) => void;
  onActual: (n: number) => void;
}) {
  const scored = declared !== null && actual !== null ? scoreTeam(declared, actual, mode) : null;
  return (
    <Card>
      <div className="mb-2 flex items-center justify-between">
        <h2 className="text-sm font-semibold">
          <span className="pip me-1 text-heart" aria-hidden>
            {suit}
          </span>
          {name}
        </h2>
        {scored && (
          <span className={scored.success ? "text-xs font-semibold text-ok" : "text-xs font-semibold text-heart"}>
            {scored.success ? "موفق" : "ناموفق"} <Num value={scored.points} signed />
          </span>
        )}
      </div>
      <Picker label="اعلام" max={10} value={declared} onChange={onDeclared} />
      {declared === 10 && (
        <p className="mt-1 text-xs text-brass">اعلام ۱۰: موفقیت ۲۰۰+ و شکست ۲۰۰−.</p>
      )}
      {declared === 8 && (
        <p className="mt-1 text-xs text-brass">اعلام ۸ و موفقیت، شرط لازم برد را کامل می‌کند و ۸۰ امتیاز دارد.</p>
      )}
      <div className="mt-3">
        <Picker label="گرفته" max={maxActual} value={actual} onChange={onActual} />
      </div>
    </Card>
  );
}

function Picker({
  label,
  max,
  value,
  onChange,
}: {
  label: string;
  max: number;
  value: number | null;
  onChange: (n: number) => void;
}) {
  return (
    <fieldset>
      <legend className="mb-1 text-xs text-ink/70">{label}</legend>
      <div className="grid grid-cols-6 gap-1.5">
        {Array.from({ length: max + 1 }, (_, n) => (
          <button
            key={n}
            type="button"
            aria-pressed={value === n}
            onClick={() => onChange(n)}
            className={cx(
              "min-h-11 rounded-lg border text-sm font-semibold",
              value === n ? "border-chip bg-chip text-card" : "border-line/40 text-ink",
            )}
          >
            {faDigits(n)}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function SummaryRow({
  name,
  declared,
  actual,
  points,
  success,
  qual,
}: {
  name: string;
  declared: number;
  actual: number;
  points: number;
  success: boolean;
  qual: boolean;
}) {
  return (
    <p className="mt-2 text-sm leading-6">
      {name}: اعلام <Num value={declared} />، گرفته <Num value={actual} />،{" "}
      <span className={success ? "text-ok" : "text-heart"}>{success ? "موفق" : "ناموفق"}</span>{" "}
      <Num value={points} signed />
      {qual ? " · شرط ۸ با این دست کامل می‌شود" : ""}
    </p>
  );
}
