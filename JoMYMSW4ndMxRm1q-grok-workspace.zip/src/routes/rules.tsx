import { createFileRoute } from "@tanstack/react-router";
import { scoreTeam } from "@/lib/dahdovist/engine";
import { faSigned } from "@/lib/dahdovist/format";
import { useGameStore } from "@/lib/dahdovist/store";
import { Card, Num, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/rules")({ component: RulesPage });

function RulesPage() {
  const mode = useGameStore((s) => s.settings.successMode);
  const rows = Array.from({ length: 11 }, (_, declared) => {
    const success = scoreTeam(declared, declared, mode).points;
    const fail =
      declared === 0 && mode === "atLeast" ? null : scoreTeam(declared, Math.max(0, declared - 1), mode).points;
    return { declared, success, fail };
  });

  return (
    <Page title="قوانین" eyebrow="ده دویست" back>
      <div className="flex flex-col gap-3 text-sm leading-6">
        <Card>
          <h2 className="font-semibold">امتیاز هر دست</h2>
          <p className="mt-1 text-ink/80">
            اگر تیم به اعلامش برسد، امتیازش اعلام ضربدر ۱۰ است. اگر نرسد، همان مقدار منفی می‌شود. رسیدن یعنی
            تعداد دست گرفته‌شده از اعلام کمتر نباشد، مگر اینکه در تنظیمات «تعداد دقیق» را انتخاب کرده باشید.
          </p>
        </Card>
        <Card>
          <h2 className="font-semibold">اعلام ۱۰</h2>
          <p className="mt-1 text-ink/80">
            اعلام ۱۰ حالت خاص است: موفقیت ۲۰۰+ و شکست ۲۰۰−. هرگز ۱۰۰ امتیاز حساب نمی‌شود.
          </p>
        </Card>
        <Card>
          <h2 className="font-semibold">شرط برد با ۸</h2>
          <p className="mt-1 text-ink/80">
            تیم وقتی می‌تواند برنده شود که یک بار دقیقاً ۸ اعلام کرده و آن اعلام موفق بوده باشد. این یک شرط
            جداست، نه فقط ۸۰ امتیاز. اعلام ناموفق ۸، هشتاد امتیاز منفی دارد و شرط را کامل نمی‌کند. اگر تیمی ۸
            دست بگیرد ولی عدد دیگری اعلام کرده باشد، شرط انجام نشده است.
          </p>
        </Card>
        <Card>
          <h2 className="font-semibold">۵۰۰ و هشدار بالای ۴۰۰</h2>
          <p className="mt-1 text-ink/80">
            برنده تیمی است که امتیازش به ۵۰۰ یا بیشتر برسد و شرط ۸ را هم داشته باشد. اگر امتیاز از ۴۰۰ بیشتر شود
            و شرط ۸ مانده باشد، هشدار می‌ماند. خود ۴۰۰ هشدار ندارد. رسیدن به ۵۰۰ بدون شرط ۸ برنده نمی‌سازد.
          </p>
          <p className="mt-2 text-xs text-heart">
            هشدار: این تیم هنوز شرط برد با اعلام و گرفتن ۸ دست را تکمیل نکرده است.
          </p>
        </Card>
        <Card>
          <h2 className="font-semibold">اگر هر دو تیم با هم به برد برسند</h2>
          <p className="mt-1 text-ink/80">
            فقط یک نتیجه اعلام می‌شود. امتیاز بالاتر برنده است. اگر امتیاز برابر باشد، بازی با تساوی تمام می‌شود
            و هیچ تیمی به‌تنهایی برنده نیست.
          </p>
        </Card>
        <Card className="overflow-x-auto">
          <h2 className="font-semibold">جدول ۰ تا ۱۰</h2>
          <p className="mt-1 text-xs text-ink/60">
            حالت فعلی موفقیت: {mode === "exact" ? "دقیقاً برابر اعلام" : "حداقل به اندازهٔ اعلام"}
          </p>
          <table className="mt-2 w-full text-xs">
            <thead>
              <tr className="text-ink/60">
                <th className="py-1 text-start font-medium">اعلام</th>
                <th className="py-1 text-start font-medium">موفق</th>
                <th className="py-1 text-start font-medium">ناموفق</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.declared} className="border-t border-ink/10">
                  <td className="py-1">
                    <Num value={row.declared} />
                    {row.declared === 8 ? " · شرط" : ""}
                    {row.declared === 10 ? " · خاص" : ""}
                  </td>
                  <td className="py-1 text-ok">
                    <bdi dir="ltr">{faSigned(row.success)}</bdi>
                  </td>
                  <td className="py-1 text-heart">{row.fail === null ? "—" : <bdi dir="ltr">{faSigned(row.fail)}</bdi>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card>
          <h2 className="font-semibold">فرض‌هایی که در خود بازی مشخص شده</h2>
          <ul className="mt-1 list-disc pe-4 text-xs leading-5 text-ink/80">
            <li>اعلام از ۰ تا ۱۰ است و برنامه آن را خودش عوض نمی‌کند.</li>
            <li>تعداد دست هر دور پیش‌فرض ۱۳ است و از ۱ تا ۲۶ در تنظیمات عوض می‌شود.</li>
            <li>مجموع دست‌های گرفته‌شده می‌تواند دقیقاً برابر، حداکثر، یا بدون قید باشد.</li>
            <li>دست اضافه در حالت «حداقل» امتیاز جدا ندارد؛ فقط اعلام را موفق می‌کند.</li>
            <li>اعلام ۰ در حالت حداقل همیشه موفق است و صفر امتیاز دارد.</li>
            <li>واگرد، آخرین دست را برمی‌دارد. ویرایش دست قدیمی جمع‌های بعدی را از نو می‌سازد.</li>
            <li>تنظیمات تازه، قانون بازی‌های قبلی را عوض نمی‌کند.</li>
            <li>همه‌چیز روی همین دستگاه می‌ماند و به اینترنت نیاز ندارد.</li>
          </ul>
        </Card>
      </div>
    </Page>
  );
}
