import { createFileRoute } from "@tanstack/react-router";
import { MAX_TRICKS_PER_ROUND, MIN_TRICKS_PER_ROUND } from "@/lib/dahdovist/engine";
import { faDigits, ruleLine } from "@/lib/dahdovist/format";
import { useGameStore } from "@/lib/dahdovist/store";
import { Card, Page } from "@/components/dah/shell";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const settings = useGameStore((s) => s.settings);
  const update = useGameStore((s) => s.updateSettings);

  return (
    <Page title="تنظیمات" back>
      <div className="flex flex-col gap-3">
        <Card>
          <h2 className="text-sm font-semibold">تعداد دست هر دور</h2>
          <p className="mt-1 text-xs text-ink/70">برای بازی‌های تازه قفل می‌شود. بازی‌های ساخته‌شده قانون خودشان را نگه می‌دارند.</p>
          <div className="mt-3 flex items-center justify-between">
            <button
              type="button"
              className="size-11 rounded-full border border-line/50 text-lg"
              aria-label="کم کردن"
              onClick={() => update({ tricksPerRound: Math.max(MIN_TRICKS_PER_ROUND, settings.tricksPerRound - 1) })}
            >
              −
            </button>
            <span className="text-2xl font-bold">
              <bdi dir="ltr">{faDigits(settings.tricksPerRound)}</bdi>
            </span>
            <button
              type="button"
              className="size-11 rounded-full border border-line/50 text-lg"
              aria-label="زیاد کردن"
              onClick={() => update({ tricksPerRound: Math.min(MAX_TRICKS_PER_ROUND, settings.tricksPerRound + 1) })}
            >
              +
            </button>
          </div>
        </Card>
        <Card>
          <h2 className="text-sm font-semibold">اعتبار مجموع دست‌ها</h2>
          <div className="mt-2 grid grid-cols-3 gap-2">
            <Choice
              on={settings.trickValidation === "exact"}
              label="دقیقاً"
              onClick={() => update({ trickValidation: "exact" })}
            />
            <Choice
              on={settings.trickValidation === "atMost"}
              label="حداکثر"
              onClick={() => update({ trickValidation: "atMost" })}
            />
            <Choice
              on={settings.trickValidation === "off"}
              label="خاموش"
              onClick={() => update({ trickValidation: "off" })}
            />
          </div>
        </Card>
        <Card>
          <h2 className="text-sm font-semibold">معنی موفقیت اعلام</h2>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Choice
              on={settings.successMode === "atLeast"}
              label="حداقل اعلام"
              onClick={() => update({ successMode: "atLeast" })}
            />
            <Choice
              on={settings.successMode === "exact"}
              label="دقیقاً برابر"
              onClick={() => update({ successMode: "exact" })}
            />
          </div>
          <p className="mt-2 text-xs leading-5 text-ink/70">
            پیش‌فرض «حداقل» است: دست بیشتر از اعلام هم موفقیت است و امتیاز اضافه ندارد. «دقیقاً» یعنی دست اضافه هم شکست است.
          </p>
        </Card>
        <Card>
          <Toggle
            label="صدای نتیجه"
            on={settings.sound}
            onClick={() => update({ sound: !settings.sound })}
          />
          <Toggle
            label="لرزش کوتاه"
            on={settings.haptic}
            onClick={() => update({ haptic: !settings.haptic })}
          />
        </Card>
        <Card>
          <h2 className="text-sm font-semibold">ظاهر</h2>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Choice on={settings.theme === "dark"} label="میز تیره" onClick={() => update({ theme: "dark" })} />
            <Choice on={settings.theme === "light"} label="میز روشن" onClick={() => update({ theme: "light" })} />
          </div>
        </Card>
        <p className="text-xs leading-5 text-muted">قانون بازی بعدی: {ruleLine(settings)}</p>
      </div>
    </Page>
  );
}

function Choice({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={`min-h-11 rounded-xl border text-xs font-semibold ${on ? "border-chip bg-chip text-card" : "border-line/40 text-ink"}`}
    >
      {label}
    </button>
  );
}

function Toggle({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex min-h-11 w-full items-center justify-between text-sm">
      <span>{label}</span>
      <span className={`rounded-full px-2 py-1 text-xs ${on ? "bg-ok/15 text-ok" : "bg-ink/10 text-ink/60"}`}>
        {on ? "روشن" : "خاموش"}
      </span>
    </button>
  );
}

